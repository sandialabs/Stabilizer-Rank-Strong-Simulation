#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <time.h>
#include "matrix.h"
#include "exponentialsum.h"
#include "shrinkstar.h"
#include "extend.h"
#include "measurepauli.h"
#include "innerproduct.h"
#include "randomstabilizerstate.h"

#define ZEROTHRESHOLD (0.00000001)

int readPaulicoeffs(int *omega, int *alpha, int *beta, int *gamma, int *delta, int numqubits);

// order of matrix elements is [row][column]!!!

int main(int argc, char *argv[])
{

  if(argc != 2) {
    printf("strongsim12_rellerr argument: \"number of stabilizer state samples\"\n");
    exit(0);
  }

  int NUMSTABSTATESAMPLES = atoi(argv[1]);        // number of stabilizer state samples

  int N;                  // number of qubits
  scanf("%d", &N);

  if(N%12 != 0) {
    printf("'N' needs to be a multiple of 12 for a k=12 tensor factor decomposition!\n");
    return 1;
  }

  int T;              // number of T gate magic states (set to the first 'K' of the 'N' qubits -- the rest are set to the '0' computational basis state)
  scanf("%d", &T);

  int omega[N]; // max of N measurements
  int alpha[N][N], beta[N][N], gamma[N][N], delta[N][N]; // max of N measurements of N Paulis
  int Paulicounter = 0;

  int i, j, k, l, m;

  FILE *fp;
  char buff[255];

  srand((unsigned)time(NULL)); // seeding the random number generator for randomstabilizerstate()
  
  fp = fopen("Pd.txt", "r");

  if(fscanf(fp, "%s", buff) == EOF) {
    printf("Error: Pd.txt should start with the number N of P(d) of values tabulated.");
    return 1;
  }
  
  double** Pd;

  int PdN = atoi(buff);

  Pd = calloc(PdN, sizeof(double*));
  for(i=0; i<PdN; i++) 
    Pd[i] = calloc(PdN+1, sizeof(double));

  double tmp;
  
  for(i=1; i<PdN; i++) {
    tmp = 0.0;
    for(j=0; j<=i; j++) {
      if(fscanf(fp, "%s", buff) == EOF) {
	printf("Error: expected more values tabulated for P(d) for N=%d", PdN);
	return 1;
      }
      Pd[i][j] = atof(buff);
      //printf("%e ", Pd[i][j]);
      tmp += Pd[i][j];
    }
    //printf("\n");
    //printf("total=%f\n", tmp);
  }


  double complex coeffb60 = (-16.0+12.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(6.0*PI*I/8.0)/8.0*cpow(2.0,3.0);
  double complex coeffb66 = (96.0-68.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(6.0*PI*I/8.0)/8.0*cpow(2.0,3.0);
  double complex coeffe6 = (10.0-7.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(6.0*PI*I/8.0)*cpow(2.0,2.5);
  double complex coeffo6 = (-14.0+10.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(-14.0*PI*I/8.0)*cpow(2.0,2.5);
  double complex coeffk6 = (7.0-5.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(-8.0*PI*I/8.0)*4.0*csqrt(2.0)*cpow(2.0,0.5);
  double complex coeffphiprime = (10.0-7.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(2.0*PI*I/8.0)*cpow(2.0,2.5);
  double complex coeffphidprime = (10.0-7.0*sqrt(2.0)+0.0*I)*pow(cos(PI/8.0),6)*cexp(2.0*PI*I/8.0)*cpow(2.0,2.5);

  // b60
  int nn1 = 6; int kk1 = 6; int (*(GG1[])) = { (int[]) {1, 0, 0, 0, 0, 0}, (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}}; int (*(GGBar1[])) = { (int[]) {1, 0, 0, 0, 0, 0}, (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}}; int hh1[] = {0, 0, 0, 0, 0, 0}; int QQ1 = 0; int DD1[] = {0, 0, 0, 0, 0, 0}; int (*(JJ1[])) = { (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0} };
  // b66
  int nn2 = 6; int kk2 = 6; int (*(GG2[])) = { (int[]) {1, 0, 0, 0, 0, 0}, (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}}; int (*(GGBar2[])) = { (int[]) {1, 0, 0, 0, 0, 0}, (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}}; int hh2[] = {0, 0, 0, 0, 0, 0}; int QQ2 = 4; int DD2[] = {4, 4, 4, 4, 4, 4}; int (*(JJ2[])) = { (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0} };
  // e6
  int nn3 = 6; int kk3 = 5; int (*(GG3[])) = { (int[]) {1, 1, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0} }; int (*(GGBar3[])) = { (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1} }; int hh3[] = {1, 0, 0, 0, 0, 0}; int QQ3 = 4; int DD3[] = {0, 0, 0, 0, 0}; int (*(JJ3[])) = { (int[]) {0, 4, 4, 4, 4}, (int[]) {4, 0, 4, 4, 4}, (int[]) {4, 4, 0, 4, 4}, (int[]) {4, 4, 4, 0, 4}, (int[]) {4, 4, 4, 4, 0}  };
  // o6
  int nn4 = 6; int kk4 = 5; int (*(GG4[])) = { (int[]) {1, 1, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0} }; int (*(GGBar4[])) = { (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1} }; int hh4[] = {0, 0, 0, 0, 0, 0}; int QQ4 = 4; int DD4[] = {4, 4, 4, 4, 4}; int (*(JJ4[])) = { (int[]) {0, 4, 4, 4, 4}, (int[]) {4, 0, 4, 4, 4}, (int[]) {4, 4, 0, 4, 4}, (int[]) {4, 4, 4, 0, 4}, (int[]) {4, 4, 4, 4, 0}  };
  // k6
  int nn5 = 6; int kk5 = 1; int (*(GG5[])) = { (int[]) {1, 1, 1, 1, 1, 1}, (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1} }; int (*(GGBar5[])) = { (int[]) {1, 0, 0, 0, 0, 0}, (int[]) {1, 1, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 1} }; int hh5[] = {1, 1, 1, 1, 1, 1}; int QQ5 = 6; int DD5[] = {2}; int (*(JJ5[])) = { (int[]) {4} };
  // phiprime
  int nn6 = 6; int kk6 = 5; int (*(GG6[])) = { (int[]) {1, 1, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0} }; int (*(GGBar6[])) = { (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1} }; int hh6[] = {1, 0, 0, 0, 0, 0}; int QQ6 = 0; int DD6[] = {0, 0, 0, 0, 0}; int (*(JJ6[])) = { (int[]) {0, 4, 0, 0, 4}, (int[]) {4, 0, 4, 0, 0}, (int[]) {0, 4, 0, 4, 0}, (int[]) {0, 0, 4, 0, 4}, (int[]) {4, 0, 0, 4, 0}  };
  // phidoubleprime
  int nn7 = 6; int kk7 = 5; int (*(GG7[])) = { (int[]) {1, 1, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0} }; int (*(GGBar7[])) = { (int[]) {0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1} }; int hh7[] = {1, 0, 0, 0, 0, 0}; int QQ7 = 0; int DD7[] = {0, 0, 0, 0, 0}; int (*(JJ7[])) = { (int[]) {0, 0, 4, 4, 0}, (int[]) {0, 0, 0, 4, 4}, (int[]) {4, 0, 0, 0, 4}, (int[]) {4, 4, 0, 0, 0}, (int[]) {0, 4, 4, 0, 0}  };

  // b60 * b60
  int n1 = nn1+nn1; int k1 = kk1+kk1; int **G1; int **GBar1; int *h1; int Q1; int *D1; int **J1;
  G1 = calloc(nn1+nn1,sizeof(int*));
  GBar1 = calloc(nn1+nn1,sizeof(int*));
  h1 = calloc(nn1+nn1,sizeof(int));
  D1 = calloc(kk1+kk1,sizeof(int));
  J1 = calloc(kk1+kk1,sizeof(int*));
  for(i=0; i<nn1+nn1; i++) {
    G1[i] = calloc(nn1+nn1, sizeof(int)); GBar1[i] = calloc(nn1+nn1, sizeof(int));
  }
  for(i=0; i<kk1+kk1; i++)
     J1[i] = calloc(kk1+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG1, G1, nn1, nn1, nn1, nn1);
  addSubMatrix(GG1, G1, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG1, G1, kk1, nn1, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G1, nn1-kk1, nn1, kk1, 0, kk1+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G1, nn1-kk1, nn1, kk1, 0, kk1+kk1+nn1-kk1, nn1);
  //appendBlockMatrix(GGBar1, GGBar1, GBar1, nn1, nn1, nn1, nn1);
  addSubMatrix(GGBar1, GBar1, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar1, kk1, nn1, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar1, nn1-kk1, nn1, kk1, 0, kk1+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar1, nn1-kk1, nn1, kk1, 0, kk1+kk1+nn1-kk1, nn1);
  appendVector(hh1, hh1, h1, nn1, nn1);
  Q1 = (QQ1+QQ1);
  appendVector(DD1, DD1, D1, kk1, kk1);
  appendBlockMatrix(JJ1, JJ1, J1, kk1, kk1, kk1, kk1);
  //addSubMatrix(JJ1, J1, kk1, kk1, 0, 0, 0, 0);
  //addSubMatrix(JJ1, J1, kk1, kk1, 0, 0, kk1, kk1);

  // b66 * b60
  /*int n2 = nn1+nn2; int k2 = kk1+kk2; int **G2; int **GBar2; int *h2; int Q2; int *D2; int **J2;
  G2 = calloc(nn1+nn2,sizeof(int*));
  GBar2 = calloc(nn1+nn2,sizeof(int*));
  h2 = calloc(nn1+nn2,sizeof(int));
  D2 = calloc(kk1+kk2,sizeof(int));
  J2 = calloc(kk1+kk2,sizeof(int*));
  for(i=0; i<nn1+nn2; i++) {
    G2[i] = calloc(nn1+nn2, sizeof(int)); GBar2[i] = calloc(nn1+nn2, sizeof(int));
  }
  for(i=0; i<kk1+kk2; i++)
     J2[i] = calloc(kk1+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG1, G2, nn2, nn2, nn1, nn1);
  addSubMatrix(GG2, G2, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG1, G2, kk1, nn1, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G2, nn2-kk2, nn2, kk2, 0, kk2+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G2, nn1-kk1, nn1, kk1, 0, kk2+kk1+nn2-kk2, nn1);
  //appendBlockMatrix(GGBar2, GGBar1, GBar2, nn2, nn2, nn1, nn1);
  addSubMatrix(GGBar2, GBar2, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar2, kk1, nn1, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar2, nn2-kk2, nn2, kk2, 0, kk2+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar2, nn1-kk1, nn1, kk1, 0, kk2+kk1+nn2-kk2, nn1);
  appendVector(hh2, hh1, h2, nn2, nn1);
  Q2 = (QQ1+QQ2);
  appendVector(DD2, DD1, D2, kk2, kk1);
  appendBlockMatrix(JJ2, JJ1, J2, kk2, kk2, kk1, kk1);*/

  // e6 * b60
  int n2 = nn1+nn3; int k2 = kk1+kk3; int **G2; int **GBar2; int *h2; int Q2; int *D2; int **J2;
  G2 = calloc(nn1+nn3,sizeof(int*));
  GBar2 = calloc(nn1+nn3,sizeof(int*));
  h2 = calloc(nn1+nn3,sizeof(int));
  D2 = calloc(kk1+kk3,sizeof(int));
  J2 = calloc(kk1+kk3,sizeof(int*));
  for(i=0; i<nn1+nn3; i++) {
    G2[i] = calloc(nn1+nn3, sizeof(int)); GBar2[i] = calloc(nn1+nn3, sizeof(int));
  }
  for(i=0; i<kk1+kk3; i++)
     J2[i] = calloc(kk1+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG1, G3, nn3, nn3, nn1, nn1);
  addSubMatrix(GG3, G2, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG1, G2, kk1, nn1, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G2, nn3-kk3, nn3, kk3, 0, kk3+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G2, nn1-kk1, nn1, kk1, 0, kk3+kk1+nn3-kk3, nn1);
  //appendBlockMatrix(GGBar3, GGBar1, GBar3, nn3, nn3, nn1, nn1);
  addSubMatrix(GGBar3, GBar2, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar2, kk1, nn1, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar2, nn3-kk3, nn3, kk3, 0, kk3+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar2, nn1-kk1, nn1, kk1, 0, kk3+kk1+nn3-kk3, nn1);
  appendVector(hh3, hh1, h2, nn3, nn1);
  Q2 = (QQ1+QQ3);
  appendVector(DD3, DD1, D2, kk3, kk1);
  appendBlockMatrix(JJ3, JJ1, J2, kk3, kk3, kk1, kk1);
  
  // o6 * b60
  int n3 = nn1+nn4; int k3 = kk1+kk4; int **G3; int **GBar3; int *h3; int Q3; int *D3; int **J3;
  G3 = calloc(nn1+nn4,sizeof(int*));
  GBar3 = calloc(nn1+nn4,sizeof(int*));
  h3 = calloc(nn1+nn4,sizeof(int));
  D3 = calloc(kk1+kk4,sizeof(int));
  J3 = calloc(kk1+kk4,sizeof(int*));
  for(i=0; i<nn1+nn4; i++) {
    G3[i] = calloc(nn1+nn4, sizeof(int)); GBar3[i] = calloc(nn1+nn4, sizeof(int));
  }
  for(i=0; i<kk1+kk4; i++)
     J3[i] = calloc(kk1+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG1, G4, nn4, nn4, nn1, nn1);
  addSubMatrix(GG4, G3, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG1, G3, kk1, nn1, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G3, nn4-kk4, nn4, kk4, 0, kk4+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G3, nn1-kk1, nn1, kk1, 0, kk4+kk1+nn4-kk4, nn1);
  //appendBlockMatrix(GGBar4, GGBar1, GBar4, nn4, nn4, nn1, nn1);
  addSubMatrix(GGBar4, GBar3, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar3, kk1, nn1, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar3, nn4-kk4, nn4, kk4, 0, kk4+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar3, nn1-kk1, nn1, kk1, 0, kk4+kk1+nn4-kk4, nn1);
  appendVector(hh4, hh1, h3, nn4, nn1);
  Q3 = (QQ1+QQ4);
  appendVector(DD4, DD1, D3, kk4, kk1);
  appendBlockMatrix(JJ4, JJ1, J3, kk4, kk4, kk1, kk1);

  // k6 * b60
  int n4 = nn1+nn5; int k4 = kk1+kk5; int **G4; int **GBar4; int *h4; int Q4; int *D4; int **J4;
  G4 = calloc(nn1+nn5,sizeof(int*));
  GBar4 = calloc(nn1+nn5,sizeof(int*));
  h4 = calloc(nn1+nn5,sizeof(int));
  D4 = calloc(kk1+kk5,sizeof(int));
  J4 = calloc(kk1+kk5,sizeof(int*));
  for(i=0; i<nn1+nn5; i++) {
    G4[i] = calloc(nn1+nn5, sizeof(int)); GBar4[i] = calloc(nn1+nn5, sizeof(int));
  }
  for(i=0; i<kk1+kk5; i++)
     J4[i] = calloc(kk1+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG1, G5, nn5, nn5, nn1, nn1);
  addSubMatrix(GG5, G4, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG1, G4, kk1, nn1, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G4, nn5-kk5, nn5, kk5, 0, kk5+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G4, nn1-kk1, nn1, kk1, 0, kk5+kk1+nn5-kk5, nn1);
  //appendBlockMatrix(GGBar5, GGBar1, GBar5, nn5, nn5, nn1, nn1);
  addSubMatrix(GGBar5, GBar4, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar4, kk1, nn1, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar4, nn5-kk5, nn5, kk5, 0, kk5+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar4, nn1-kk1, nn1, kk1, 0, kk5+kk1+nn5-kk5, nn1);
  appendVector(hh5, hh1, h4, nn5, nn1);
  Q4 = (QQ1+QQ5);
  appendVector(DD5, DD1, D4, kk5, kk1);
  appendBlockMatrix(JJ5, JJ1, J4, kk5, kk5, kk1, kk1);

  // phiprime * b60 
  int n5 = nn1+nn6; int k5 = kk1+kk6; int **G5; int **GBar5; int *h5; int Q5; int *D5; int **J5;
  G5 = calloc(nn1+nn6,sizeof(int*));
  GBar5 = calloc(nn1+nn6,sizeof(int*));
  h5 = calloc(nn1+nn6,sizeof(int));
  D5 = calloc(kk1+kk6,sizeof(int));
  J5 = calloc(kk1+kk6,sizeof(int*));
  for(i=0; i<nn1+nn6; i++) {
    G5[i] = calloc(nn1+nn6, sizeof(int)); GBar5[i] = calloc(nn1+nn6, sizeof(int));
  }
  for(i=0; i<kk1+kk6; i++)
     J5[i] = calloc(kk1+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG1, G6, nn6, nn6, nn1, nn1);
  addSubMatrix(GG6, G5, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG1, G5, kk1, nn1, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G5, nn6-kk6, nn6, kk6, 0, kk6+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G5, nn1-kk1, nn1, kk1, 0, kk6+kk1+nn6-kk6, nn1);
  //appendBlockMatrix(GGBar6, GGBar1, GBar6, nn6, nn6, nn1, nn1);
  addSubMatrix(GGBar6, GBar5, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar5, kk1, nn1, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar5, nn6-kk6, nn6, kk6, 0, kk6+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar5, nn1-kk1, nn1, kk1, 0, kk6+kk1+nn6-kk6, nn1);
  appendVector(hh6, hh1, h5, nn6, nn1);
  Q5 = (QQ1+QQ6);
  appendVector(DD6, DD1, D5, kk6, kk1);
  appendBlockMatrix(JJ6, JJ1, J5, kk6, kk6, kk1, kk1);
  
  // phidprime * b60
  int n6 = nn1+nn7; int k6 = kk1+kk7; int **G6; int **GBar6; int *h6; int Q6; int *D6; int **J6;
  G6 = calloc(nn1+nn7,sizeof(int*));
  GBar6 = calloc(nn1+nn7,sizeof(int*));
  h6 = calloc(nn1+nn7,sizeof(int));
  D6 = calloc(kk1+kk7,sizeof(int));
  J6 = calloc(kk1+kk7,sizeof(int*));
  for(i=0; i<nn1+nn7; i++) {
    G6[i] = calloc(nn1+nn7, sizeof(int)); GBar6[i] = calloc(nn1+nn7, sizeof(int));
  }
  for(i=0; i<kk1+kk7; i++)
     J6[i] = calloc(kk1+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG1, G7, nn7, nn7, nn1, nn1);
  addSubMatrix(GG7, G6, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG1, G6, kk1, nn1, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G6, nn7-kk7, nn7, kk7, 0, kk7+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG1, G6, nn1-kk1, nn1, kk1, 0, kk7+kk1+nn7-kk7, nn1);
  //appendBlockMatrix(GGBar7, GGBar1, GBar7, nn7, nn7, nn1, nn1);
  addSubMatrix(GGBar7, GBar6, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar1, GBar6, kk1, nn1, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar6, nn7-kk7, nn7, kk7, 0, kk7+kk1, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar1, GBar6, nn1-kk1, nn1, kk1, 0, kk7+kk1+nn7-kk7, nn1);
  appendVector(hh7, hh1, h6, nn7, nn1);
  Q6 = (QQ1+QQ7);
  appendVector(DD7, DD1, D6, kk7, kk1);
  appendBlockMatrix(JJ7, JJ1, J6, kk7, kk7, kk1, kk1);

  // b60 * b66
  /*int n8 = nn2+nn1; int k8 = kk2+kk1; int **G8; int **GBar8; int *h8; int Q8; int *D8; int **J8;
  G8 = calloc(nn2+nn1,sizeof(int*));
  GBar8 = calloc(nn2+nn1,sizeof(int*));
  h8 = calloc(nn2+nn1,sizeof(int));
  D8 = calloc(kk2+kk1,sizeof(int));
  J8 = calloc(kk2+kk1,sizeof(int*));
  for(i=0; i<nn2+nn1; i++) {
    G8[i] = calloc(nn2+nn1, sizeof(int)); GBar8[i] = calloc(nn2+nn1, sizeof(int));
  }
  for(i=0; i<kk2+kk1; i++)
     J8[i] = calloc(kk2+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG2, G8, nn1, nn1, nn2, nn2);
  addSubMatrix(GG1, G8, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG2, G8, kk2, nn2, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G8, nn1-kk1, nn1, kk1, 0, kk1+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G8, nn2-kk2, nn2, kk2, 0, kk1+kk2+nn1-kk1, nn2);
  //appendBlockMatrix(GGBar1, GGBar2, GBar8, nn1, nn1, nn2, nn2);
  addSubMatrix(GGBar1, GBar8, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar8, kk2, nn2, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar8, nn1-kk1, nn1, kk1, 0, kk1+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar8, nn2-kk2, nn2, kk2, 0, kk1+kk2+nn1-kk1, nn2);
  appendVector(hh1, hh2, h8, nn1, nn2);
  Q8 = (QQ2+QQ1);
  appendVector(DD1, DD2, D8, kk1, kk2);
  appendBlockMatrix(JJ1, JJ2, J8, kk1, kk1, kk2, kk2);*/

  // b66 * b66
  int n7 = nn2+nn2; int k7 = kk2+kk2; int **G7; int **GBar7; int *h7; int Q7; int *D7; int **J7;
  G7 = calloc(nn2+nn2,sizeof(int*));
  GBar7 = calloc(nn2+nn2,sizeof(int*));
  h7 = calloc(nn2+nn2,sizeof(int));
  D7 = calloc(kk2+kk2,sizeof(int));
  J7 = calloc(kk2+kk2,sizeof(int*));
  for(i=0; i<nn2+nn2; i++) {
    G7[i] = calloc(nn2+nn2, sizeof(int)); GBar7[i] = calloc(nn2+nn2, sizeof(int));
  }
  for(i=0; i<kk2+kk2; i++)
     J7[i] = calloc(kk2+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG2, G9, nn2, nn2, nn2, nn2);
  addSubMatrix(GG2, G7, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG2, G7, kk2, nn2, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G7, nn2-kk2, nn2, kk2, 0, kk2+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G7, nn2-kk2, nn2, kk2, 0, kk2+kk2+nn2-kk2, nn2);
  //appendBlockMatrix(GGBar2, GGBar2, GBar9, nn2, nn2, nn2, nn2);
  addSubMatrix(GGBar2, GBar7, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar7, kk2, nn2, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar7, nn2-kk2, nn2, kk2, 0, kk2+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar7, nn2-kk2, nn2, kk2, 0, kk2+kk2+nn2-kk2, nn2);
  appendVector(hh2, hh2, h7, nn2, nn2);
  Q7 = (QQ2+QQ2);
  appendVector(DD2, DD2, D7, kk2, kk2);
  appendBlockMatrix(JJ2, JJ2, J7, kk2, kk2, kk2, kk2);

  // e6 * b66
  int n8 = nn2+nn3; int k8 = kk2+kk3; int **G8; int **GBar8; int *h8; int Q8; int *D8; int **J8;
  G8 = calloc(nn2+nn3,sizeof(int*));
  GBar8 = calloc(nn2+nn3,sizeof(int*));
  h8 = calloc(nn2+nn3,sizeof(int));
  D8 = calloc(kk2+kk3,sizeof(int));
  J8 = calloc(kk2+kk3,sizeof(int*));
  for(i=0; i<nn2+nn3; i++) {
    G8[i] = calloc(nn2+nn3, sizeof(int)); GBar8[i] = calloc(nn2+nn3, sizeof(int));
  }
  for(i=0; i<kk2+kk3; i++)
     J8[i] = calloc(kk2+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG2, G10, nn3, nn3, nn2, nn2);
  addSubMatrix(GG3, G8, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG2, G8, kk2, nn2, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G8, nn3-kk3, nn3, kk3, 0, kk3+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G8, nn2-kk2, nn2, kk2, 0, kk3+kk2+nn3-kk3, nn2);
  //appendBlockMatrix(GGBar3, GGBar2, GBar10, nn3, nn3, nn2, nn2);
  addSubMatrix(GGBar3, GBar8, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar8, kk2, nn2, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar8, nn3-kk3, nn3, kk3, 0, kk3+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar8, nn2-kk2, nn2, kk2, 0, kk3+kk2+nn3-kk3, nn2);
  appendVector(hh3, hh2, h8, nn3, nn2);
  Q8 = (QQ2+QQ3);
  appendVector(DD3, DD2, D8, kk3, kk2);
  appendBlockMatrix(JJ3, JJ2, J8, kk3, kk3, kk2, kk2);

  // o6 * b66
  int n9 = nn2+nn4; int k9 = kk2+kk4; int **G9; int **GBar9; int *h9; int Q9; int *D9; int **J9;
  G9 = calloc(nn2+nn4,sizeof(int*));
  GBar9 = calloc(nn2+nn4,sizeof(int*));
  h9 = calloc(nn2+nn4,sizeof(int));
  D9 = calloc(kk2+kk4,sizeof(int));
  J9 = calloc(kk2+kk4,sizeof(int*));
  for(i=0; i<nn2+nn4; i++) {
    G9[i] = calloc(nn2+nn4, sizeof(int)); GBar9[i] = calloc(nn2+nn4, sizeof(int));
  }
  for(i=0; i<kk2+kk4; i++)
     J9[i] = calloc(kk2+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG2, G11, nn4, nn4, nn2, nn2);
  addSubMatrix(GG4, G9, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG2, G9, kk2, nn2, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G9, nn4-kk4, nn4, kk4, 0, kk4+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G9, nn2-kk2, nn2, kk2, 0, kk4+kk2+nn4-kk4, nn2);
  //appendBlockMatrix(GGBar4, GGBar2, GBar11, nn4, nn4, nn2, nn2);
  addSubMatrix(GGBar4, GBar9, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar9, kk2, nn2, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar9, nn4-kk4, nn4, kk4, 0, kk4+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar9, nn2-kk2, nn2, kk2, 0, kk4+kk2+nn4-kk4, nn2);
  appendVector(hh4, hh2, h9, nn4, nn2);
  Q9 = (QQ2+QQ4);
  appendVector(DD4, DD2, D9, kk4, kk2);
  appendBlockMatrix(JJ4, JJ2, J9, kk4, kk4, kk2, kk2);

  // k6 * b66
  int n10 = nn2+nn5; int k10 = kk2+kk5; int **G10; int **GBar10; int *h10; int Q10; int *D10; int **J10;
  G10 = calloc(nn2+nn5,sizeof(int*));
  GBar10 = calloc(nn2+nn5,sizeof(int*));
  h10 = calloc(nn2+nn5,sizeof(int));
  D10 = calloc(kk2+kk5,sizeof(int));
  J10 = calloc(kk2+kk5,sizeof(int*));
  for(i=0; i<nn2+nn5; i++) {
    G10[i] = calloc(nn2+nn5, sizeof(int)); GBar10[i] = calloc(nn2+nn5, sizeof(int));
  }
  for(i=0; i<kk2+kk5; i++)
     J10[i] = calloc(kk2+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG2, G12, nn5, nn5, nn2, nn2);
  addSubMatrix(GG5, G10, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG2, G10, kk2, nn2, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G10, nn5-kk5, nn5, kk5, 0, kk5+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G10, nn2-kk2, nn2, kk2, 0, kk5+kk2+nn5-kk5, nn2);
  //appendBlockMatrix(GGBar5, GGBar2, GBar12, nn5, nn5, nn2, nn2);
  addSubMatrix(GGBar5, GBar10, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar10, kk2, nn2, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar10, nn5-kk5, nn5, kk5, 0, kk5+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar10, nn2-kk2, nn2, kk2, 0, kk5+kk2+nn5-kk5, nn2);
  appendVector(hh5, hh2, h10, nn5, nn2);
  Q10 = (QQ2+QQ5);
  appendVector(DD5, DD2, D10, kk5, kk2);
  appendBlockMatrix(JJ5, JJ2, J10, kk5, kk5, kk2, kk2);
  
  // phiprime * b66
  int n11 = nn2+nn6; int k11 = kk2+kk6; int **G11; int **GBar11; int *h11; int Q11; int *D11; int **J11;
  G11 = calloc(nn2+nn6,sizeof(int*));
  GBar11 = calloc(nn2+nn6,sizeof(int*));
  h11 = calloc(nn2+nn6,sizeof(int));
  D11 = calloc(kk2+kk6,sizeof(int));
  J11 = calloc(kk2+kk6,sizeof(int*));
  for(i=0; i<nn2+nn6; i++) {
    G11[i] = calloc(nn2+nn6, sizeof(int)); GBar11[i] = calloc(nn2+nn6, sizeof(int));
  }
  for(i=0; i<kk2+kk6; i++)
     J11[i] = calloc(kk2+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG2, G13, nn6, nn6, nn2, nn2);
  addSubMatrix(GG6, G11, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG2, G11, kk2, nn2, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G11, nn6-kk6, nn6, kk6, 0, kk6+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G11, nn2-kk2, nn2, kk2, 0, kk6+kk2+nn6-kk6, nn2);
  //appendBlockMatrix(GGBar6, GGBar2, GBar13, nn6, nn6, nn2, nn2);
  addSubMatrix(GGBar6, GBar11, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar11, kk2, nn2, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar11, nn6-kk6, nn6, kk6, 0, kk6+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar11, nn2-kk2, nn2, kk2, 0, kk6+kk2+nn6-kk6, nn2);
  appendVector(hh6, hh2, h11, nn6, nn2);
  Q11 = (QQ2+QQ6);
  appendVector(DD6, DD2, D11, kk6, kk2);
  appendBlockMatrix(JJ6, JJ2, J11, kk6, kk6, kk2, kk2);

  // phidprime * b66
  int n12 = nn2+nn7; int k12 = kk2+kk7; int **G12; int **GBar12; int *h12; int Q12; int *D12; int **J12;
  G12 = calloc(nn2+nn7,sizeof(int*));
  GBar12 = calloc(nn2+nn7,sizeof(int*));
  h12 = calloc(nn2+nn7,sizeof(int));
  D12 = calloc(kk2+kk7,sizeof(int));
  J12 = calloc(kk2+kk7,sizeof(int*));
  for(i=0; i<nn2+nn7; i++) {
    G12[i] = calloc(nn2+nn7, sizeof(int)); GBar12[i] = calloc(nn2+nn7, sizeof(int));
  }
  for(i=0; i<kk2+kk7; i++)
     J12[i] = calloc(kk2+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG2, G14, nn7, nn7, nn2, nn2);
  addSubMatrix(GG7, G12, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG2, G12, kk2, nn2, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G12, nn7-kk7, nn7, kk7, 0, kk7+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG2, G12, nn2-kk2, nn2, kk2, 0, kk7+kk2+nn7-kk7, nn2);
  //appendBlockMatrix(GGBar7, GGBar2, GBar14, nn7, nn7, nn2, nn2);
  addSubMatrix(GGBar7, GBar12, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar2, GBar12, kk2, nn2, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar12, nn7-kk7, nn7, kk7, 0, kk7+kk2, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar2, GBar12, nn2-kk2, nn2, kk2, 0, kk7+kk2+nn7-kk7, nn2);
  appendVector(hh7, hh2, h12, nn7, nn2);
  Q12 = (QQ2+QQ7);
  appendVector(DD7, DD2, D12, kk7, kk2);
  appendBlockMatrix(JJ7, JJ2, J12, kk7, kk7, kk2, kk2);

  // b60 * e6
  int n13 = nn3+nn1; int k13 = kk3+kk1; int **G13; int **GBar13; int *h13; int Q13; int *D13; int **J13;
  G13 = calloc(nn3+nn1,sizeof(int*));
  GBar13 = calloc(nn3+nn1,sizeof(int*));
  h13 = calloc(nn3+nn1,sizeof(int));
  D13 = calloc(kk3+kk1,sizeof(int));
  J13 = calloc(kk3+kk1,sizeof(int*));
  for(i=0; i<nn3+nn1; i++) {
    G13[i] = calloc(nn3+nn1, sizeof(int)); GBar13[i] = calloc(nn3+nn1, sizeof(int));
  }
  for(i=0; i<kk3+kk1; i++)
     J13[i] = calloc(kk3+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG3, G15, nn1, nn1, nn3, nn3);
  addSubMatrix(GG1, G13, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG3, G13, kk3, nn3, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G13, nn1-kk1, nn1, kk1, 0, kk1+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G13, nn3-kk3, nn3, kk3, 0, kk1+kk3+nn1-kk1, nn3);
  //appendBlockMatrix(GGBar1, GGBar3, GBar15, nn1, nn1, nn3, nn3);
  addSubMatrix(GGBar1, GBar13, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar13, kk3, nn3, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar13, nn1-kk1, nn1, kk1, 0, kk1+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar13, nn3-kk3, nn3, kk3, 0, kk1+kk3+nn1-kk1, nn3);
  appendVector(hh1, hh3, h13, nn1, nn3);
  Q13 = (QQ3+QQ1);
  appendVector(DD1, DD3, D13, kk1, kk3);
  appendBlockMatrix(JJ1, JJ3, J13, kk1, kk1, kk3, kk3);

  // b66 * e6
  int n14 = nn3+nn2; int k14 = kk3+kk2; int **G14; int **GBar14; int *h14; int Q14; int *D14; int **J14;
  G14 = calloc(nn3+nn2,sizeof(int*));
  GBar14 = calloc(nn3+nn2,sizeof(int*));
  h14 = calloc(nn3+nn2,sizeof(int));
  D14 = calloc(kk3+kk2,sizeof(int));
  J14 = calloc(kk3+kk2,sizeof(int*));
  for(i=0; i<nn3+nn2; i++) {
    G14[i] = calloc(nn3+nn2, sizeof(int)); GBar14[i] = calloc(nn3+nn2, sizeof(int));
  }
  for(i=0; i<kk3+kk2; i++)
     J14[i] = calloc(kk3+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG3, G16, nn2, nn2, nn3, nn3);
  addSubMatrix(GG2, G14, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG3, G14, kk3, nn3, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G14, nn2-kk2, nn2, kk2, 0, kk2+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G14, nn3-kk3, nn3, kk3, 0, kk2+kk3+nn2-kk2, nn3);
  //appendBlockMatrix(GGBar2, GGBar3, GBar16, nn2, nn2, nn3, nn3);
  addSubMatrix(GGBar2, GBar14, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar14, kk3, nn3, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar14, nn2-kk2, nn2, kk2, 0, kk2+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar14, nn3-kk3, nn3, kk3, 0, kk2+kk3+nn2-kk2, nn3);
  appendVector(hh2, hh3, h14, nn2, nn3);
  Q14 = (QQ3+QQ2);
  appendVector(DD2, DD3, D14, kk2, kk3);
  appendBlockMatrix(JJ2, JJ3, J14, kk2, kk2, kk3, kk3);

  // e6 * e6
  int n15 = nn3+nn3; int k15 = kk3+kk3; int **G15; int **GBar15; int *h15; int Q15; int *D15; int **J15;
  G15 = calloc(nn3+nn3,sizeof(int*));
  GBar15 = calloc(nn3+nn3,sizeof(int*));
  h15 = calloc(nn3+nn3,sizeof(int));
  D15 = calloc(kk3+kk3,sizeof(int));
  J15 = calloc(kk3+kk3,sizeof(int*));
  for(i=0; i<nn3+nn3; i++) {
    G15[i] = calloc(nn3+nn3, sizeof(int)); GBar15[i] = calloc(nn3+nn3, sizeof(int));
  }
  for(i=0; i<kk3+kk3; i++)
     J15[i] = calloc(kk3+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG3, G17, nn3, nn3, nn3, nn3);
  addSubMatrix(GG3, G15, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG3, G15, kk3, nn3, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G15, nn3-kk3, nn3, kk3, 0, kk3+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G15, nn3-kk3, nn3, kk3, 0, kk3+kk3+nn3-kk3, nn3);
  //appendBlockMatrix(GGBar3, GGBar3, GBar17, nn3, nn3, nn3, nn3);
  addSubMatrix(GGBar3, GBar15, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar15, kk3, nn3, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar15, nn3-kk3, nn3, kk3, 0, kk3+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar15, nn3-kk3, nn3, kk3, 0, kk3+kk3+nn3-kk3, nn3);
  appendVector(hh3, hh3, h15, nn3, nn3);
  Q15 = (QQ3+QQ3);
  appendVector(DD3, DD3, D15, kk3, kk3);
  appendBlockMatrix(JJ3, JJ3, J15, kk3, kk3, kk3, kk3);

  // o6 * e6
  /*int n18 = nn3+nn4; int k18 = kk3+kk4; int **G18; int **GBar18; int *h18; int Q18; int *D18; int **J18;
  G18 = calloc(nn3+nn4,sizeof(int*));
  GBar18 = calloc(nn3+nn4,sizeof(int*));
  h18 = calloc(nn3+nn4,sizeof(int));
  D18 = calloc(kk3+kk4,sizeof(int));
  J18 = calloc(kk3+kk4,sizeof(int*));
  for(i=0; i<nn3+nn4; i++) {
    G18[i] = calloc(nn3+nn4, sizeof(int)); GBar18[i] = calloc(nn3+nn4, sizeof(int));
  }
  for(i=0; i<kk3+kk4; i++)
     J18[i] = calloc(kk3+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG3, G18, nn4, nn4, nn3, nn3);
  addSubMatrix(GG4, G18, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG3, G18, kk3, nn3, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G18, nn4-kk4, nn4, kk4, 0, kk4+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G18, nn3-kk3, nn3, kk3, 0, kk4+kk3+nn4-kk4, nn3);
  //appendBlockMatrix(GGBar4, GGBar3, GBar18, nn4, nn4, nn3, nn3);
  addSubMatrix(GGBar4, GBar18, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar18, kk3, nn3, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar18, nn4-kk4, nn4, kk4, 0, kk4+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar18, nn3-kk3, nn3, kk3, 0, kk4+kk3+nn4-kk4, nn3);
  appendVector(hh4, hh3, h18, nn4, nn3);
  Q18 = (QQ3+QQ4);
  appendVector(DD4, DD3, D18, kk4, kk3);
  appendBlockMatrix(JJ4, JJ3, J18, kk4, kk4, kk3, kk3);*/

  // k6 * e6
  int n16 = nn3+nn5; int k16 = kk3+kk5; int **G16; int **GBar16; int *h16; int Q16; int *D16; int **J16;
  G16 = calloc(nn3+nn5,sizeof(int*));
  GBar16 = calloc(nn3+nn5,sizeof(int*));
  h16 = calloc(nn3+nn5,sizeof(int));
  D16 = calloc(kk3+kk5,sizeof(int));
  J16 = calloc(kk3+kk5,sizeof(int*));
  for(i=0; i<nn3+nn5; i++) {
    G16[i] = calloc(nn3+nn5, sizeof(int)); GBar16[i] = calloc(nn3+nn5, sizeof(int));
  }
  for(i=0; i<kk3+kk5; i++)
     J16[i] = calloc(kk3+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG3, G19, nn5, nn5, nn3, nn3);
  addSubMatrix(GG5, G16, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG3, G16, kk3, nn3, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G16, nn5-kk5, nn5, kk5, 0, kk5+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G16, nn3-kk3, nn3, kk3, 0, kk5+kk3+nn5-kk5, nn3);
  //appendBlockMatrix(GGBar5, GGBar3, GBar19, nn5, nn5, nn3, nn3);
  addSubMatrix(GGBar5, GBar16, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar16, kk3, nn3, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar16, nn5-kk5, nn5, kk5, 0, kk5+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar16, nn3-kk3, nn3, kk3, 0, kk5+kk3+nn5-kk5, nn3);
  appendVector(hh5, hh3, h16, nn5, nn3);
  Q16 = (QQ3+QQ5);
  appendVector(DD5, DD3, D16, kk5, kk3);
  appendBlockMatrix(JJ5, JJ3, J16, kk5, kk5, kk3, kk3);
  
  // phiprime * e6
  int n17 = nn3+nn6; int k17 = kk3+kk6; int **G17; int **GBar17; int *h17; int Q17; int *D17; int **J17;
  G17 = calloc(nn3+nn6,sizeof(int*));
  GBar17 = calloc(nn3+nn6,sizeof(int*));
  h17 = calloc(nn3+nn6,sizeof(int));
  D17 = calloc(kk3+kk6,sizeof(int));
  J17 = calloc(kk3+kk6,sizeof(int*));
  for(i=0; i<nn3+nn6; i++) {
    G17[i] = calloc(nn3+nn6, sizeof(int)); GBar17[i] = calloc(nn3+nn6, sizeof(int));
  }
  for(i=0; i<kk3+kk6; i++)
     J17[i] = calloc(kk3+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG3, G20, nn6, nn6, nn3, nn3);
  addSubMatrix(GG6, G17, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG3, G17, kk3, nn3, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G17, nn6-kk6, nn6, kk6, 0, kk6+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G17, nn3-kk3, nn3, kk3, 0, kk6+kk3+nn6-kk6, nn3);
  //appendBlockMatrix(GGBar6, GGBar3, GBar20, nn6, nn6, nn3, nn3);
  addSubMatrix(GGBar6, GBar17, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar17, kk3, nn3, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar17, nn6-kk6, nn6, kk6, 0, kk6+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar17, nn3-kk3, nn3, kk3, 0, kk6+kk3+nn6-kk6, nn3);
  appendVector(hh6, hh3, h17, nn6, nn3);
  Q17 = (QQ3+QQ6);
  appendVector(DD6, DD3, D17, kk6, kk3);
  appendBlockMatrix(JJ6, JJ3, J17, kk6, kk6, kk3, kk3);

  // phidprime * e6
  int n18 = nn3+nn7; int k18 = kk3+kk7; int **G18; int **GBar18; int *h18; int Q18; int *D18; int **J18;
  G18 = calloc(nn3+nn7,sizeof(int*));
  GBar18 = calloc(nn3+nn7,sizeof(int*));
  h18 = calloc(nn3+nn7,sizeof(int));
  D18 = calloc(kk3+kk7,sizeof(int));
  J18 = calloc(kk3+kk7,sizeof(int*));
  for(i=0; i<nn3+nn7; i++) {
    G18[i] = calloc(nn3+nn7, sizeof(int)); GBar18[i] = calloc(nn3+nn7, sizeof(int));
  }
  for(i=0; i<kk3+kk7; i++)
     J18[i] = calloc(kk3+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG3, G21, nn7, nn7, nn3, nn3);
  addSubMatrix(GG7, G18, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG3, G18, kk3, nn3, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G18, nn7-kk7, nn7, kk7, 0, kk7+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG3, G18, nn3-kk3, nn3, kk3, 0, kk7+kk3+nn7-kk7, nn3);
  //appendBlockMatrix(GGBar7, GGBar3, GBar21, nn7, nn7, nn3, nn3);
  addSubMatrix(GGBar7, GBar18, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar3, GBar18, kk3, nn3, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar18, nn7-kk7, nn7, kk7, 0, kk7+kk3, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar3, GBar18, nn3-kk3, nn3, kk3, 0, kk7+kk3+nn7-kk7, nn3);
  appendVector(hh7, hh3, h18, nn7, nn3);
  Q18 = (QQ3+QQ7);
  appendVector(DD7, DD3, D18, kk7, kk3);
  appendBlockMatrix(JJ7, JJ3, J18, kk7, kk7, kk3, kk3);

  // b60 * o6
  int n19 = nn4+nn1; int k19 = kk4+kk1; int **G19; int **GBar19; int *h19; int Q19; int *D19; int **J19;
  G19 = calloc(nn4+nn1,sizeof(int*));
  GBar19 = calloc(nn4+nn1,sizeof(int*));
  h19 = calloc(nn4+nn1,sizeof(int));
  D19 = calloc(kk4+kk1,sizeof(int));
  J19 = calloc(kk4+kk1,sizeof(int*));
  for(i=0; i<nn4+nn1; i++) {
    G19[i] = calloc(nn4+nn1, sizeof(int)); GBar19[i] = calloc(nn4+nn1, sizeof(int));
  }
  for(i=0; i<kk4+kk1; i++)
     J19[i] = calloc(kk4+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG4, G22, nn1, nn1, nn4, nn4);
  addSubMatrix(GG1, G19, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG4, G19, kk4, nn4, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G19, nn1-kk1, nn1, kk1, 0, kk1+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G19, nn4-kk4, nn4, kk4, 0, kk1+kk4+nn1-kk1, nn4);
  //appendBlockMatrix(GGBar1, GGBar4, GBar22, nn1, nn1, nn4, nn4);
  addSubMatrix(GGBar1, GBar19, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar19, kk4, nn4, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar19, nn1-kk1, nn1, kk1, 0, kk1+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar19, nn4-kk4, nn4, kk4, 0, kk1+kk4+nn1-kk1, nn4);
  appendVector(hh1, hh4, h19, nn1, nn4);
  Q19 = (QQ4+QQ1);
  appendVector(DD1, DD4, D19, kk1, kk4);
  appendBlockMatrix(JJ1, JJ4, J19, kk1, kk1, kk4, kk4);

  // b66 * o6
  int n20 = nn4+nn2; int k20 = kk4+kk2; int **G20; int **GBar20; int *h20; int Q20; int *D20; int **J20;
  G20 = calloc(nn4+nn2,sizeof(int*));
  GBar20 = calloc(nn4+nn2,sizeof(int*));
  h20 = calloc(nn4+nn2,sizeof(int));
  D20 = calloc(kk4+kk2,sizeof(int));
  J20 = calloc(kk4+kk2,sizeof(int*));
  for(i=0; i<nn4+nn2; i++) {
    G20[i] = calloc(nn4+nn2, sizeof(int)); GBar20[i] = calloc(nn4+nn2, sizeof(int));
  }
  for(i=0; i<kk4+kk2; i++)
     J20[i] = calloc(kk4+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG4, G23, nn2, nn2, nn4, nn4);
  addSubMatrix(GG2, G20, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG4, G20, kk4, nn4, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G20, nn2-kk2, nn2, kk2, 0, kk2+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G20, nn4-kk4, nn4, kk4, 0, kk2+kk4+nn2-kk2, nn4);
  //appendBlockMatrix(GGBar2, GGBar4, GBar23, nn2, nn2, nn4, nn4);
  addSubMatrix(GGBar2, GBar20, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar20, kk4, nn4, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar20, nn2-kk2, nn2, kk2, 0, kk2+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar20, nn4-kk4, nn4, kk4, 0, kk2+kk4+nn2-kk2, nn4);
  appendVector(hh2, hh4, h20, nn2, nn4);
  Q20 = (QQ4+QQ2);
  appendVector(DD2, DD4, D20, kk2, kk4);
  appendBlockMatrix(JJ2, JJ4, J20, kk2, kk2, kk4, kk4);
  
  // e6 * o6
  /*int n24 = nn4+nn3; int k24 = kk4+kk3; int **G24; int **GBar24; int *h24; int Q24; int *D24; int **J24;
  G24 = calloc(nn4+nn3,sizeof(int*));
  GBar24 = calloc(nn4+nn3,sizeof(int*));
  h24 = calloc(nn4+nn3,sizeof(int));
  D24 = calloc(kk4+kk3,sizeof(int));
  J24 = calloc(kk4+kk3,sizeof(int*));
  for(i=0; i<nn4+nn3; i++) {
    G24[i] = calloc(nn4+nn3, sizeof(int)); GBar24[i] = calloc(nn4+nn3, sizeof(int));
  }
  for(i=0; i<kk4+kk3; i++)
     J24[i] = calloc(kk4+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG4, G24, nn3, nn3, nn4, nn4);
  addSubMatrix(GG3, G24, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG4, G24, kk4, nn4, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G24, nn3-kk3, nn3, kk3, 0, kk3+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G24, nn4-kk4, nn4, kk4, 0, kk3+kk4+nn3-kk3, nn4);
  //appendBlockMatrix(GGBar3, GGBar4, GBar24, nn3, nn3, nn4, nn4);
  addSubMatrix(GGBar3, GBar24, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar24, kk4, nn4, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar24, nn3-kk3, nn3, kk3, 0, kk3+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar24, nn4-kk4, nn4, kk4, 0, kk3+kk4+nn3-kk3, nn4);
  appendVector(hh3, hh4, h24, nn3, nn4);
  Q24 = (QQ4+QQ3);
  appendVector(DD3, DD4, D24, kk3, kk4);
  appendBlockMatrix(JJ3, JJ4, J24, kk3, kk3, kk4, kk4);*/

  // o6 * o6
  int n21 = nn4+nn4; int k21 = kk4+kk4; int **G21; int **GBar21; int *h21; int Q21; int *D21; int **J21;
  G21 = calloc(nn4+nn4,sizeof(int*));
  GBar21 = calloc(nn4+nn4,sizeof(int*));
  h21 = calloc(nn4+nn4,sizeof(int));
  D21 = calloc(kk4+kk4,sizeof(int));
  J21 = calloc(kk4+kk4,sizeof(int*));
  for(i=0; i<nn4+nn4; i++) {
    G21[i] = calloc(nn4+nn4, sizeof(int)); GBar21[i] = calloc(nn4+nn4, sizeof(int));
  }
  for(i=0; i<kk4+kk4; i++)
     J21[i] = calloc(kk4+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG4, G25, nn4, nn4, nn4, nn4);
  addSubMatrix(GG4, G21, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG4, G21, kk4, nn4, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G21, nn4-kk4, nn4, kk4, 0, kk4+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G21, nn4-kk4, nn4, kk4, 0, kk4+kk4+nn4-kk4, nn4);
  //appendBlockMatrix(GGBar4, GGBar4, GBar25, nn4, nn4, nn4, nn4);
  addSubMatrix(GGBar4, GBar21, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar21, kk4, nn4, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar21, nn4-kk4, nn4, kk4, 0, kk4+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar21, nn4-kk4, nn4, kk4, 0, kk4+kk4+nn4-kk4, nn4);
  appendVector(hh4, hh4, h21, nn4, nn4);
  Q21 = (QQ4+QQ4);
  appendVector(DD4, DD4, D21, kk4, kk4);
  appendBlockMatrix(JJ4, JJ4, J21, kk4, kk4, kk4, kk4);

  // k6 * o6
  int n22 = nn4+nn5; int k22 = kk4+kk5; int **G22; int **GBar22; int *h22; int Q22; int *D22; int **J22;
  G22 = calloc(nn4+nn5,sizeof(int*));
  GBar22 = calloc(nn4+nn5,sizeof(int*));
  h22 = calloc(nn4+nn5,sizeof(int));
  D22 = calloc(kk4+kk5,sizeof(int));
  J22 = calloc(kk4+kk5,sizeof(int*));
  for(i=0; i<nn4+nn5; i++) {
    G22[i] = calloc(nn4+nn5, sizeof(int)); GBar22[i] = calloc(nn4+nn5, sizeof(int));
  }
  for(i=0; i<kk4+kk5; i++)
     J22[i] = calloc(kk4+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG4, G26, nn5, nn5, nn4, nn4);
  addSubMatrix(GG5, G22, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG4, G22, kk4, nn4, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G22, nn5-kk5, nn5, kk5, 0, kk5+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G22, nn4-kk4, nn4, kk4, 0, kk5+kk4+nn5-kk5, nn4);
  //appendBlockMatrix(GGBar5, GGBar4, GBar26, nn5, nn5, nn4, nn4);
  addSubMatrix(GGBar5, GBar22, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar22, kk4, nn4, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar22, nn5-kk5, nn5, kk5, 0, kk5+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar22, nn4-kk4, nn4, kk4, 0, kk5+kk4+nn5-kk5, nn4);
  appendVector(hh5, hh4, h22, nn5, nn4);
  Q22 = (QQ4+QQ5);
  appendVector(DD5, DD4, D22, kk5, kk4);
  appendBlockMatrix(JJ5, JJ4, J22, kk5, kk5, kk4, kk4);
  
  // phiprime * o6
  int n23 = nn4+nn6; int k23 = kk4+kk6; int **G23; int **GBar23; int *h23; int Q23; int *D23; int **J23;
  G23 = calloc(nn4+nn6,sizeof(int*));
  GBar23 = calloc(nn4+nn6,sizeof(int*));
  h23 = calloc(nn4+nn6,sizeof(int));
  D23 = calloc(kk4+kk6,sizeof(int));
  J23 = calloc(kk4+kk6,sizeof(int*));
  for(i=0; i<nn4+nn6; i++) {
    G23[i] = calloc(nn4+nn6, sizeof(int)); GBar23[i] = calloc(nn4+nn6, sizeof(int));
  }
  for(i=0; i<kk4+kk6; i++)
     J23[i] = calloc(kk4+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG4, G27, nn6, nn6, nn4, nn4);
  addSubMatrix(GG6, G23, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG4, G23, kk4, nn4, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G23, nn6-kk6, nn6, kk6, 0, kk6+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G23, nn4-kk4, nn4, kk4, 0, kk6+kk4+nn6-kk6, nn4);
  //appendBlockMatrix(GGBar6, GGBar4, GBar27, nn6, nn6, nn4, nn4);
  addSubMatrix(GGBar6, GBar23, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar23, kk4, nn4, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar23, nn6-kk6, nn6, kk6, 0, kk6+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar23, nn4-kk4, nn4, kk4, 0, kk6+kk4+nn6-kk6, nn4);
  appendVector(hh6, hh4, h23, nn6, nn4);
  Q23 = (QQ4+QQ6);
  appendVector(DD6, DD4, D23, kk6, kk4);
  appendBlockMatrix(JJ6, JJ4, J23, kk6, kk6, kk4, kk4);

  // phidprime * o6
  int n24 = nn4+nn7; int k24 = kk4+kk7; int **G24; int **GBar24; int *h24; int Q24; int *D24; int **J24;
  G24 = calloc(nn4+nn7,sizeof(int*));
  GBar24 = calloc(nn4+nn7,sizeof(int*));
  h24 = calloc(nn4+nn7,sizeof(int));
  D24 = calloc(kk4+kk7,sizeof(int));
  J24 = calloc(kk4+kk7,sizeof(int*));
  for(i=0; i<nn4+nn7; i++) {
    G24[i] = calloc(nn4+nn7, sizeof(int)); GBar24[i] = calloc(nn4+nn7, sizeof(int));
  }
  for(i=0; i<kk4+kk7; i++)
     J24[i] = calloc(kk4+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG4, G28, nn7, nn7, nn4, nn4);
  addSubMatrix(GG7, G24, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG4, G24, kk4, nn4, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G24, nn7-kk7, nn7, kk7, 0, kk7+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG4, G24, nn4-kk4, nn4, kk4, 0, kk7+kk4+nn7-kk7, nn4);
  //appendBlockMatrix(GGBar7, GGBar4, GBar28, nn7, nn7, nn4, nn4);
  addSubMatrix(GGBar7, GBar24, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar4, GBar24, kk4, nn4, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar24, nn7-kk7, nn7, kk7, 0, kk7+kk4, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar4, GBar24, nn4-kk4, nn4, kk4, 0, kk7+kk4+nn7-kk7, nn4);
  appendVector(hh7, hh4, h24, nn7, nn4);
  Q24 = (QQ4+QQ7);
  appendVector(DD7, DD4, D24, kk7, kk4);
  appendBlockMatrix(JJ7, JJ4, J24, kk7, kk7, kk4, kk4);

  // b60 * k6
  int n25 = nn5+nn1; int k25 = kk5+kk1; int **G25; int **GBar25; int *h25; int Q25; int *D25; int **J25;
  G25 = calloc(nn5+nn1,sizeof(int*));
  GBar25 = calloc(nn5+nn1,sizeof(int*));
  h25 = calloc(nn5+nn1,sizeof(int));
  D25 = calloc(kk5+kk1,sizeof(int));
  J25 = calloc(kk5+kk1,sizeof(int*));
  for(i=0; i<nn5+nn1; i++) {
    G25[i] = calloc(nn5+nn1, sizeof(int)); GBar25[i] = calloc(nn5+nn1, sizeof(int));
  }
  for(i=0; i<kk5+kk1; i++)
     J25[i] = calloc(kk5+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG5, G29, nn1, nn1, nn5, nn5);
  addSubMatrix(GG1, G25, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG5, G25, kk5, nn5, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G25, nn1-kk1, nn1, kk1, 0, kk1+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G25, nn5-kk5, nn5, kk5, 0, kk1+kk5+nn1-kk1, nn5);
  //appendBlockMatrix(GGBar1, GGBar5, GBar29, nn1, nn1, nn5, nn5);
  addSubMatrix(GGBar1, GBar25, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar25, kk5, nn5, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar25, nn1-kk1, nn1, kk1, 0, kk1+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar25, nn5-kk5, nn5, kk5, 0, kk1+kk5+nn1-kk1, nn5);
  appendVector(hh1, hh5, h25, nn1, nn5);
  Q25 = (QQ5+QQ1);
  appendVector(DD1, DD5, D25, kk1, kk5);
  appendBlockMatrix(JJ1, JJ5, J25, kk1, kk1, kk5, kk5);

  // b66 * k6
  int n26 = nn5+nn2; int k26 = kk5+kk2; int **G26; int **GBar26; int *h26; int Q26; int *D26; int **J26;
  G26 = calloc(nn5+nn2,sizeof(int*));
  GBar26 = calloc(nn5+nn2,sizeof(int*));
  h26 = calloc(nn5+nn2,sizeof(int));
  D26 = calloc(kk5+kk2,sizeof(int));
  J26 = calloc(kk5+kk2,sizeof(int*));
  for(i=0; i<nn5+nn2; i++) {
    G26[i] = calloc(nn5+nn2, sizeof(int)); GBar26[i] = calloc(nn5+nn2, sizeof(int));
  }
  for(i=0; i<kk5+kk2; i++)
     J26[i] = calloc(kk5+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG5, G30, nn2, nn2, nn5, nn5);
  addSubMatrix(GG2, G26, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG5, G26, kk5, nn5, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G26, nn2-kk2, nn2, kk2, 0, kk2+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G26, nn5-kk5, nn5, kk5, 0, kk2+kk5+nn2-kk2, nn5);
  //appendBlockMatrix(GGBar2, GGBar5, GBar30, nn2, nn2, nn5, nn5);
  addSubMatrix(GGBar2, GBar26, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar26, kk5, nn5, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar26, nn2-kk2, nn2, kk2, 0, kk2+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar26, nn5-kk5, nn5, kk5, 0, kk2+kk5+nn2-kk2, nn5);
  appendVector(hh2, hh5, h26, nn2, nn5);
  Q26 = (QQ5+QQ2);
  appendVector(DD2, DD5, D26, kk2, kk5);
  appendBlockMatrix(JJ2, JJ5, J26, kk2, kk2, kk5, kk5);
  
  // e6 * k6
  int n27 = nn5+nn3; int k27 = kk5+kk3; int **G27; int **GBar27; int *h27; int Q27; int *D27; int **J27;
  G27 = calloc(nn5+nn3,sizeof(int*));
  GBar27 = calloc(nn5+nn3,sizeof(int*));
  h27 = calloc(nn5+nn3,sizeof(int));
  D27 = calloc(kk5+kk3,sizeof(int));
  J27 = calloc(kk5+kk3,sizeof(int*));
  for(i=0; i<nn5+nn3; i++) {
    G27[i] = calloc(nn5+nn3, sizeof(int)); GBar27[i] = calloc(nn5+nn3, sizeof(int));
  }
  for(i=0; i<kk5+kk3; i++)
     J27[i] = calloc(kk5+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG5, G31, nn3, nn3, nn5, nn5);
  addSubMatrix(GG3, G27, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG5, G27, kk5, nn5, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G27, nn3-kk3, nn3, kk3, 0, kk3+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G27, nn5-kk5, nn5, kk5, 0, kk3+kk5+nn3-kk3, nn5);
  //appendBlockMatrix(GGBar3, GGBar5, GBar31, nn3, nn3, nn5, nn5);
  addSubMatrix(GGBar3, GBar27, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar27, kk5, nn5, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar27, nn3-kk3, nn3, kk3, 0, kk3+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar27, nn5-kk5, nn5, kk5, 0, kk3+kk5+nn3-kk3, nn5);
  appendVector(hh3, hh5, h27, nn3, nn5);
  Q27 = (QQ5+QQ3);
  appendVector(DD3, DD5, D27, kk3, kk5);
  appendBlockMatrix(JJ3, JJ5, J27, kk3, kk3, kk5, kk5);

  // o6 * k6
  int n28 = nn5+nn4; int k28 = kk5+kk4; int **G28; int **GBar28; int *h28; int Q28; int *D28; int **J28;
  G28 = calloc(nn5+nn4,sizeof(int*));
  GBar28 = calloc(nn5+nn4,sizeof(int*));
  h28 = calloc(nn5+nn4,sizeof(int));
  D28 = calloc(kk5+kk4,sizeof(int));
  J28 = calloc(kk5+kk4,sizeof(int*));
  for(i=0; i<nn5+nn4; i++) {
    G28[i] = calloc(nn5+nn4, sizeof(int)); GBar28[i] = calloc(nn5+nn4, sizeof(int));
  }
  for(i=0; i<kk5+kk4; i++)
     J28[i] = calloc(kk5+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG5, G32, nn4, nn4, nn5, nn5);
  addSubMatrix(GG4, G28, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG5, G28, kk5, nn5, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G28, nn4-kk4, nn4, kk4, 0, kk4+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G28, nn5-kk5, nn5, kk5, 0, kk4+kk5+nn4-kk4, nn5);
  //appendBlockMatrix(GGBar4, GGBar5, GBar32, nn4, nn4, nn5, nn5);
  addSubMatrix(GGBar4, GBar28, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar28, kk5, nn5, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar28, nn4-kk4, nn4, kk4, 0, kk4+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar28, nn5-kk5, nn5, kk5, 0, kk4+kk5+nn4-kk4, nn5);
  appendVector(hh4, hh5, h28, nn4, nn5);
  Q28 = (QQ5+QQ4);
  appendVector(DD4, DD5, D28, kk4, kk5);
  appendBlockMatrix(JJ4, JJ5, J28, kk4, kk4, kk5, kk5);

  // k6 * k6
  int n29 = nn5+nn5; int k29 = kk5+kk5; int **G29; int **GBar29; int *h29; int Q29; int *D29; int **J29;
  G29 = calloc(nn5+nn5,sizeof(int*));
  GBar29 = calloc(nn5+nn5,sizeof(int*));
  h29 = calloc(nn5+nn5,sizeof(int));
  D29 = calloc(kk5+kk5,sizeof(int));
  J29 = calloc(kk5+kk5,sizeof(int*));
  for(i=0; i<nn5+nn5; i++) {
    G29[i] = calloc(nn5+nn5, sizeof(int)); GBar29[i] = calloc(nn5+nn5, sizeof(int));
  }
  for(i=0; i<kk5+kk5; i++)
     J29[i] = calloc(kk5+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG5, G33, nn5, nn5, nn5, nn5);
  addSubMatrix(GG5, G29, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG5, G29, kk5, nn5, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G29, nn5-kk5, nn5, kk5, 0, kk5+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G29, nn5-kk5, nn5, kk5, 0, kk5+kk5+nn5-kk5, nn5);
  //appendBlockMatrix(GGBar5, GGBar5, GBar33, nn5, nn5, nn5, nn5);
  addSubMatrix(GGBar5, GBar29, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar29, kk5, nn5, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar29, nn5-kk5, nn5, kk5, 0, kk5+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar29, nn5-kk5, nn5, kk5, 0, kk5+kk5+nn5-kk5, nn5);
  appendVector(hh5, hh5, h29, nn5, nn5);
  Q29 = (QQ5+QQ5);
  appendVector(DD5, DD5, D29, kk5, kk5);
  appendBlockMatrix(JJ5, JJ5, J29, kk5, kk5, kk5, kk5);

  // phiprime * k6
  int n30 = nn5+nn6; int k30 = kk5+kk6; int **G30; int **GBar30; int *h30; int Q30; int *D30; int **J30;
  G30 = calloc(nn5+nn6,sizeof(int*));
  GBar30 = calloc(nn5+nn6,sizeof(int*));
  h30 = calloc(nn5+nn6,sizeof(int));
  D30 = calloc(kk5+kk6,sizeof(int));
  J30 = calloc(kk5+kk6,sizeof(int*));
  for(i=0; i<nn5+nn6; i++) {
    G30[i] = calloc(nn5+nn6, sizeof(int)); GBar30[i] = calloc(nn5+nn6, sizeof(int));
  }
  for(i=0; i<kk5+kk6; i++)
     J30[i] = calloc(kk5+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG5, G34, nn6, nn6, nn5, nn5);
  addSubMatrix(GG6, G30, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG5, G30, kk5, nn5, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G30, nn6-kk6, nn6, kk6, 0, kk6+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G30, nn5-kk5, nn5, kk5, 0, kk6+kk5+nn6-kk6, nn5);
  //appendBlockMatrix(GGBar6, GGBar5, GBar34, nn6, nn6, nn5, nn5);
  addSubMatrix(GGBar6, GBar30, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar30, kk5, nn5, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar30, nn6-kk6, nn6, kk6, 0, kk6+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar30, nn5-kk5, nn5, kk5, 0, kk6+kk5+nn6-kk6, nn5);
  appendVector(hh6, hh5, h30, nn6, nn5);
  Q30 = (QQ5+QQ6);
  appendVector(DD6, DD5, D30, kk6, kk5);
  appendBlockMatrix(JJ6, JJ5, J30, kk6, kk6, kk5, kk5);
  
  // phidprime * k6
  int n31 = nn5+nn7; int k31 = kk5+kk7; int **G31; int **GBar31; int *h31; int Q31; int *D31; int **J31;
  G31 = calloc(nn5+nn7,sizeof(int*));
  GBar31 = calloc(nn5+nn7,sizeof(int*));
  h31 = calloc(nn5+nn7,sizeof(int));
  D31 = calloc(kk5+kk7,sizeof(int));
  J31 = calloc(kk5+kk7,sizeof(int*));
  for(i=0; i<nn5+nn7; i++) {
    G31[i] = calloc(nn5+nn7, sizeof(int)); GBar31[i] = calloc(nn5+nn7, sizeof(int));
  }
  for(i=0; i<kk5+kk7; i++)
     J31[i] = calloc(kk5+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG5, G35, nn7, nn7, nn5, nn5);
  addSubMatrix(GG7, G31, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG5, G31, kk5, nn5, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G31, nn7-kk7, nn7, kk7, 0, kk7+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG5, G31, nn5-kk5, nn5, kk5, 0, kk7+kk5+nn7-kk7, nn5);
  //appendBlockMatrix(GGBar7, GGBar5, GBar35, nn7, nn7, nn5, nn5);
  addSubMatrix(GGBar7, GBar31, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar5, GBar31, kk5, nn5, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar31, nn7-kk7, nn7, kk7, 0, kk7+kk5, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar5, GBar31, nn5-kk5, nn5, kk5, 0, kk7+kk5+nn7-kk7, nn5);
  appendVector(hh7, hh5, h31, nn7, nn5);
  Q31 = (QQ5+QQ7);
  appendVector(DD7, DD5, D31, kk7, kk5);
  appendBlockMatrix(JJ7, JJ5, J31, kk7, kk7, kk5, kk5);

  // b60 * phiprime
  int n32 = nn6+nn1; int k32 = kk6+kk1; int **G32; int **GBar32; int *h32; int Q32; int *D32; int **J32;
  G32 = calloc(nn6+nn1,sizeof(int*));
  GBar32 = calloc(nn6+nn1,sizeof(int*));
  h32 = calloc(nn6+nn1,sizeof(int));
  D32 = calloc(kk6+kk1,sizeof(int));
  J32 = calloc(kk6+kk1,sizeof(int*));
  for(i=0; i<nn6+nn1; i++) {
    G32[i] = calloc(nn6+nn1, sizeof(int)); GBar32[i] = calloc(nn6+nn1, sizeof(int));
  }
  for(i=0; i<kk6+kk1; i++)
     J32[i] = calloc(kk6+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG6, G36, nn1, nn1, nn6, nn6);
  addSubMatrix(GG1, G32, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG6, G32, kk6, nn6, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G32, nn1-kk1, nn1, kk1, 0, kk1+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G32, nn6-kk6, nn6, kk6, 0, kk1+kk6+nn1-kk1, nn6);
  //appendBlockMatrix(GGBar1, GGBar6, GBar36, nn1, nn1, nn6, nn6);
  addSubMatrix(GGBar1, GBar32, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar32, kk6, nn6, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar32, nn1-kk1, nn1, kk1, 0, kk1+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar32, nn6-kk6, nn6, kk6, 0, kk1+kk6+nn1-kk1, nn6);
  appendVector(hh1, hh6, h32, nn1, nn6);
  Q32 = (QQ6+QQ1);
  appendVector(DD1, DD6, D32, kk1, kk6);
  appendBlockMatrix(JJ1, JJ6, J32, kk1, kk1, kk6, kk6);

  // b66 * phiprime
  int n33 = nn6+nn2; int k33 = kk6+kk2; int **G33; int **GBar33; int *h33; int Q33; int *D33; int **J33;
  G33 = calloc(nn6+nn2,sizeof(int*));
  GBar33 = calloc(nn6+nn2,sizeof(int*));
  h33 = calloc(nn6+nn2,sizeof(int));
  D33 = calloc(kk6+kk2,sizeof(int));
  J33 = calloc(kk6+kk2,sizeof(int*));
  for(i=0; i<nn6+nn2; i++) {
    G33[i] = calloc(nn6+nn2, sizeof(int)); GBar33[i] = calloc(nn6+nn2, sizeof(int));
  }
  for(i=0; i<kk6+kk2; i++)
     J33[i] = calloc(kk6+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG6, G37, nn2, nn2, nn6, nn6);
  addSubMatrix(GG2, G33, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG6, G33, kk6, nn6, 0, 0, kk2, nn2);
  addSubMatrix(GG2, G33, nn2-kk2, nn2, kk2, 0, kk2+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G33, nn6-kk6, nn6, kk6, 0, kk2+kk6+nn2-kk2, nn6);
  //appendBlockMatrix(GGBar2, GGBar6, GBar37, nn2, nn2, nn6, nn6);
  addSubMatrix(GGBar2, GBar33, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar33, kk6, nn6, 0, 0, kk2, nn2);
  addSubMatrix(GGBar2, GBar33, nn2-kk2, nn2, kk2, 0, kk2+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar33, nn6-kk6, nn6, kk6, 0, kk2+kk6+nn2-kk2, nn6);
  appendVector(hh2, hh6, h33, nn2, nn6);
  Q33 = (QQ6+QQ2);
  appendVector(DD2, DD6, D33, kk2, kk6);
  appendBlockMatrix(JJ2, JJ6, J33, kk2, kk2, kk6, kk6);

  // e6 * phiprime
  int n34 = nn6+nn3; int k34 = kk6+kk3; int **G34; int **GBar34; int *h34; int Q34; int *D34; int **J34;
  G34 = calloc(nn6+nn3,sizeof(int*));
  GBar34 = calloc(nn6+nn3,sizeof(int*));
  h34 = calloc(nn6+nn3,sizeof(int));
  D34 = calloc(kk6+kk3,sizeof(int));
  J34 = calloc(kk6+kk3,sizeof(int*));
  for(i=0; i<nn6+nn3; i++) {
    G34[i] = calloc(nn6+nn3, sizeof(int)); GBar34[i] = calloc(nn6+nn3, sizeof(int));
  }
  for(i=0; i<kk6+kk3; i++)
     J34[i] = calloc(kk6+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG6, G38, nn3, nn3, nn6, nn6);
  addSubMatrix(GG3, G34, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG6, G34, kk6, nn6, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G34, nn3-kk3, nn3, kk3, 0, kk3+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G34, nn6-kk6, nn6, kk6, 0, kk3+kk6+nn3-kk3, nn6);
  //appendBlockMatrix(GGBar3, GGBar6, GBar38, nn3, nn3, nn6, nn6);
  addSubMatrix(GGBar3, GBar34, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar34, kk6, nn6, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar34, nn3-kk3, nn3, kk3, 0, kk3+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar34, nn6-kk6, nn6, kk6, 0, kk3+kk6+nn3-kk3, nn6);
  appendVector(hh3, hh6, h34, nn3, nn6);
  Q34 = (QQ6+QQ3);
  appendVector(DD3, DD6, D34, kk3, kk6);
  appendBlockMatrix(JJ3, JJ6, J34, kk3, kk3, kk6, kk6);

  // o6 * phiprime
  int n35 = nn6+nn4; int k35 = kk6+kk4; int **G35; int **GBar35; int *h35; int Q35; int *D35; int **J35;
  G35 = calloc(nn6+nn4,sizeof(int*));
  GBar35 = calloc(nn6+nn4,sizeof(int*));
  h35 = calloc(nn6+nn4,sizeof(int));
  D35 = calloc(kk6+kk4,sizeof(int));
  J35 = calloc(kk6+kk4,sizeof(int*));
  for(i=0; i<nn6+nn4; i++) {
    G35[i] = calloc(nn6+nn4, sizeof(int)); GBar35[i] = calloc(nn6+nn4, sizeof(int));
  }
  for(i=0; i<kk6+kk4; i++)
     J35[i] = calloc(kk6+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG6, G39, nn4, nn4, nn6, nn6);
  addSubMatrix(GG4, G35, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG6, G35, kk6, nn6, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G35, nn4-kk4, nn4, kk4, 0, kk4+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G35, nn6-kk6, nn6, kk6, 0, kk4+kk6+nn4-kk4, nn6);
  //appendBlockMatrix(GGBar4, GGBar6, GBar39, nn4, nn4, nn6, nn6);
  addSubMatrix(GGBar4, GBar35, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar35, kk6, nn6, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar35, nn4-kk4, nn4, kk4, 0, kk4+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar35, nn6-kk6, nn6, kk6, 0, kk4+kk6+nn4-kk4, nn6);
  appendVector(hh4, hh6, h35, nn4, nn6);
  Q35 = (QQ6+QQ4);
  appendVector(DD4, DD6, D35, kk4, kk6);
  appendBlockMatrix(JJ4, JJ6, J35, kk4, kk4, kk6, kk6);

  // k6 * phiprime
  int n36 = nn6+nn5; int k36 = kk6+kk5; int **G36; int **GBar36; int *h36; int Q36; int *D36; int **J36;
  G36 = calloc(nn6+nn5,sizeof(int*));
  GBar36 = calloc(nn6+nn5,sizeof(int*));
  h36 = calloc(nn6+nn5,sizeof(int));
  D36 = calloc(kk6+kk5,sizeof(int));
  J36 = calloc(kk6+kk5,sizeof(int*));
  for(i=0; i<nn6+nn5; i++) {
    G36[i] = calloc(nn6+nn5, sizeof(int)); GBar36[i] = calloc(nn6+nn5, sizeof(int));
  }
  for(i=0; i<kk6+kk5; i++)
     J36[i] = calloc(kk6+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG6, G40, nn5, nn5, nn6, nn6);
  addSubMatrix(GG5, G36, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG6, G36, kk6, nn6, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G36, nn5-kk5, nn5, kk5, 0, kk5+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G36, nn6-kk6, nn6, kk6, 0, kk5+kk6+nn5-kk5, nn6);
  //appendBlockMatrix(GGBar5, GGBar6, GBar40, nn5, nn5, nn6, nn6);
  addSubMatrix(GGBar5, GBar36, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar36, kk6, nn6, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar36, nn5-kk5, nn5, kk5, 0, kk5+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar36, nn6-kk6, nn6, kk6, 0, kk5+kk6+nn5-kk5, nn6);
  appendVector(hh5, hh6, h36, nn5, nn6);
  Q36 = (QQ6+QQ5);
  appendVector(DD5, DD6, D36, kk5, kk6);
  appendBlockMatrix(JJ5, JJ6, J36, kk5, kk5, kk6, kk6);

  // phiprime * phiprime
  int n37 = nn6+nn6; int k37 = kk6+kk6; int **G37; int **GBar37; int *h37; int Q37; int *D37; int **J37;
  G37 = calloc(nn6+nn6,sizeof(int*));
  GBar37 = calloc(nn6+nn6,sizeof(int*));
  h37 = calloc(nn6+nn6,sizeof(int));
  D37 = calloc(kk6+kk6,sizeof(int));
  J37 = calloc(kk6+kk6,sizeof(int*));
  for(i=0; i<nn6+nn6; i++) {
    G37[i] = calloc(nn6+nn6, sizeof(int)); GBar37[i] = calloc(nn6+nn6, sizeof(int));
  }
  for(i=0; i<kk6+kk6; i++)
     J37[i] = calloc(kk6+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG6, G41, nn6, nn6, nn6, nn6);
  addSubMatrix(GG6, G37, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG6, G37, kk6, nn6, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G37, nn6-kk6, nn6, kk6, 0, kk6+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G37, nn6-kk6, nn6, kk6, 0, kk6+kk6+nn6-kk6, nn6);
  //appendBlockMatrix(GGBar6, GGBar6, GBar41, nn6, nn6, nn6, nn6);
  addSubMatrix(GGBar6, GBar37, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar37, kk6, nn6, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar37, nn6-kk6, nn6, kk6, 0, kk6+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar37, nn6-kk6, nn6, kk6, 0, kk6+kk6+nn6-kk6, nn6);
  appendVector(hh6, hh6, h37, nn6, nn6);
  Q37 = (QQ6+QQ6);
  appendVector(DD6, DD6, D37, kk6, kk6);
  appendBlockMatrix(JJ6, JJ6, J37, kk6, kk6, kk6, kk6);

  // phidprime * phiprime
  int n38 = nn6+nn7; int k38 = kk6+kk7; int **G38; int **GBar38; int *h38; int Q38; int *D38; int **J38;
  G38 = calloc(nn6+nn7,sizeof(int*));
  GBar38 = calloc(nn6+nn7,sizeof(int*));
  h38 = calloc(nn6+nn7,sizeof(int));
  D38 = calloc(kk6+kk7,sizeof(int));
  J38 = calloc(kk6+kk7,sizeof(int*));
  for(i=0; i<nn6+nn7; i++) {
    G38[i] = calloc(nn6+nn7, sizeof(int)); GBar38[i] = calloc(nn6+nn7, sizeof(int));
  }
  for(i=0; i<kk6+kk7; i++)
     J38[i] = calloc(kk6+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG6, G42, nn7, nn7, nn6, nn6);
  addSubMatrix(GG7, G38, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG6, G38, kk6, nn6, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G38, nn7-kk7, nn7, kk7, 0, kk7+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG6, G38, nn6-kk6, nn6, kk6, 0, kk7+kk6+nn7-kk7, nn6);
  //appendBlockMatrix(GGBar7, GGBar6, GBar42, nn7, nn7, nn6, nn6);
  addSubMatrix(GGBar7, GBar38, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar6, GBar38, kk6, nn6, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar38, nn7-kk7, nn7, kk7, 0, kk7+kk6, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar6, GBar38, nn6-kk6, nn6, kk6, 0, kk7+kk6+nn7-kk7, nn6);
  appendVector(hh7, hh6, h38, nn7, nn6);
  Q38 = (QQ6+QQ7);
  appendVector(DD7, DD6, D38, kk7, kk6);
  appendBlockMatrix(JJ7, JJ6, J38, kk7, kk7, kk6, kk6);

  // b60 * phidprime
  int n39 = nn7+nn1; int k39 = kk7+kk1; int **G39; int **GBar39; int *h39; int Q39; int *D39; int **J39;
  G39 = calloc(nn7+nn1,sizeof(int*));
  GBar39 = calloc(nn7+nn1,sizeof(int*));
  h39 = calloc(nn7+nn1,sizeof(int));
  D39 = calloc(kk7+kk1,sizeof(int));
  J39 = calloc(kk7+kk1,sizeof(int*));
  for(i=0; i<nn7+nn1; i++) {
    G39[i] = calloc(nn7+nn1, sizeof(int)); GBar39[i] = calloc(nn7+nn1, sizeof(int));
  }
  for(i=0; i<kk7+kk1; i++)
     J39[i] = calloc(kk7+kk1, sizeof(int));
  //appendBlockMatrix(GG1, GG7, G43, nn1, nn1, nn7, nn7);
  addSubMatrix(GG1, G39, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GG7, G39, kk7, nn7, 0, 0, kk1, nn1);
  addSubMatrix(GG1, G39, nn1-kk1, nn1, kk1, 0, kk1+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G39, nn7-kk7, nn7, kk7, 0, kk1+kk7+nn1-kk1, nn7);
  //appendBlockMatrix(GGBar1, GGBar7, GBar43, nn1, nn1, nn7, nn7);
  addSubMatrix(GGBar1, GBar39, kk1, nn1, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar39, kk7, nn7, 0, 0, kk1, nn1);
  addSubMatrix(GGBar1, GBar39, nn1-kk1, nn1, kk1, 0, kk1+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar39, nn7-kk7, nn7, kk7, 0, kk1+kk7+nn1-kk1, nn7);
  appendVector(hh1, hh7, h39, nn1, nn7);
  Q39 = (QQ7+QQ1);
  appendVector(DD1, DD7, D39, kk1, kk7);
  appendBlockMatrix(JJ1, JJ7, J39, kk1, kk1, kk7, kk7);
  
  // b66 * phidprime
  int n40 = nn7+nn2; int k40 = kk7+kk2; int **G40; int **GBar40; int *h40; int Q40; int *D40; int **J40;
  G40 = calloc(nn7+nn2,sizeof(int*));
  GBar40 = calloc(nn7+nn2,sizeof(int*));
  h40 = calloc(nn7+nn2,sizeof(int));
  D40 = calloc(kk7+kk2,sizeof(int));
  J40 = calloc(kk7+kk2,sizeof(int*));
  for(i=0; i<nn7+nn2; i++) {
    G40[i] = calloc(nn7+nn2, sizeof(int)); GBar40[i] = calloc(nn7+nn2, sizeof(int));
  }
  for(i=0; i<kk7+kk2; i++)
     J40[i] = calloc(kk7+kk2, sizeof(int));
  //appendBlockMatrix(GG2, GG7, G44, nn2, nn2, nn7, nn7);
  addSubMatrix(GG2, G40, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GG7, G40, kk7, nn7, 0, 0, kk2, nn2);
  addSubMatrix(GG1, G40, nn2-kk2, nn2, kk2, 0, kk2+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G40, nn7-kk7, nn7, kk7, 0, kk2+kk7+nn2-kk2, nn7);
  //appendBlockMatrix(GGBar2, GGBar7, GBar44, nn2, nn2, nn7, nn7);
  addSubMatrix(GGBar2, GBar40, kk2, nn2, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar40, kk7, nn7, 0, 0, kk2, nn2);
  addSubMatrix(GGBar1, GBar40, nn2-kk2, nn2, kk2, 0, kk2+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar40, nn7-kk7, nn7, kk7, 0, kk2+kk7+nn2-kk2, nn7);
  appendVector(hh2, hh7, h40, nn2, nn7);
  Q40 = (QQ7+QQ2);
  appendVector(DD2, DD7, D40, kk2, kk7);
  appendBlockMatrix(JJ2, JJ7, J40, kk2, kk2, kk7, kk7);
  
  // e6 * phidprime
  int n41 = nn7+nn3; int k41 = kk7+kk3; int **G41; int **GBar41; int *h41; int Q41; int *D41; int **J41;
  G41 = calloc(nn7+nn3,sizeof(int*));
  GBar41 = calloc(nn7+nn3,sizeof(int*));
  h41 = calloc(nn7+nn3,sizeof(int));
  D41 = calloc(kk7+kk3,sizeof(int));
  J41 = calloc(kk7+kk3,sizeof(int*));
  for(i=0; i<nn7+nn3; i++) {
    G41[i] = calloc(nn7+nn3, sizeof(int)); GBar41[i] = calloc(nn7+nn3, sizeof(int));
  }
  for(i=0; i<kk7+kk3; i++)
     J41[i] = calloc(kk7+kk3, sizeof(int));
  //appendBlockMatrix(GG3, GG7, G45, nn3, nn3, nn7, nn7);
  addSubMatrix(GG3, G41, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GG7, G41, kk7, nn7, 0, 0, kk3, nn3);
  addSubMatrix(GG3, G41, nn3-kk3, nn3, kk3, 0, kk3+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G41, nn7-kk7, nn7, kk7, 0, kk3+kk7+nn3-kk3, nn7);
  //appendBlockMatrix(GGBar3, GGBar7, GBar45, nn3, nn3, nn7, nn7);
  addSubMatrix(GGBar3, GBar41, kk3, nn3, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar41, kk7, nn7, 0, 0, kk3, nn3);
  addSubMatrix(GGBar3, GBar41, nn3-kk3, nn3, kk3, 0, kk3+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar41, nn7-kk7, nn7, kk7, 0, kk3+kk7+nn3-kk3, nn7);
  appendVector(hh3, hh7, h41, nn3, nn7);
  Q41 = (QQ7+QQ3);
  appendVector(DD3, DD7, D41, kk3, kk7);
  appendBlockMatrix(JJ3, JJ7, J41, kk3, kk3, kk7, kk7);

  // o6 * phidprime
  int n42 = nn7+nn4; int k42 = kk7+kk4; int **G42; int **GBar42; int *h42; int Q42; int *D42; int **J42;
  G42 = calloc(nn7+nn4,sizeof(int*));
  GBar42 = calloc(nn7+nn4,sizeof(int*));
  h42 = calloc(nn7+nn4,sizeof(int));
  D42 = calloc(kk7+kk4,sizeof(int));
  J42 = calloc(kk7+kk4,sizeof(int*));
  for(i=0; i<nn7+nn4; i++) {
    G42[i] = calloc(nn7+nn4, sizeof(int)); GBar42[i] = calloc(nn7+nn4, sizeof(int));
  }
  for(i=0; i<kk7+kk4; i++)
     J42[i] = calloc(kk7+kk4, sizeof(int));
  //appendBlockMatrix(GG4, GG7, G46, nn4, nn4, nn7, nn7);
  addSubMatrix(GG4, G42, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GG7, G42, kk7, nn7, 0, 0, kk4, nn4);
  addSubMatrix(GG4, G42, nn4-kk4, nn4, kk4, 0, kk4+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G42, nn7-kk7, nn7, kk7, 0, kk4+kk7+nn4-kk4, nn7);
  //appendBlockMatrix(GGBar4, GGBar7, GBar46, nn4, nn4, nn7, nn7);
  addSubMatrix(GGBar4, GBar42, kk4, nn4, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar42, kk7, nn7, 0, 0, kk4, nn4);
  addSubMatrix(GGBar4, GBar42, nn4-kk4, nn4, kk4, 0, kk4+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar42, nn7-kk7, nn7, kk7, 0, kk4+kk7+nn4-kk4, nn7);
  appendVector(hh4, hh7, h42, nn4, nn7);
  Q42 = (QQ7+QQ4);
  appendVector(DD4, DD7, D42, kk4, kk7);
  appendBlockMatrix(JJ4, JJ7, J42, kk4, kk4, kk7, kk7);

  // k6 * phidprime
  int n43 = nn7+nn5; int k43 = kk7+kk5; int **G43; int **GBar43; int *h43; int Q43; int *D43; int **J43;
  G43 = calloc(nn7+nn5,sizeof(int*));
  GBar43 = calloc(nn7+nn5,sizeof(int*));
  h43 = calloc(nn7+nn5,sizeof(int));
  D43 = calloc(kk7+kk5,sizeof(int));
  J43 = calloc(kk7+kk5,sizeof(int*));
  for(i=0; i<nn7+nn5; i++) {
    G43[i] = calloc(nn7+nn5, sizeof(int)); GBar43[i] = calloc(nn7+nn5, sizeof(int));
  }
  for(i=0; i<kk7+kk5; i++)
     J43[i] = calloc(kk7+kk5, sizeof(int));
  //appendBlockMatrix(GG5, GG7, G47, nn5, nn5, nn7, nn7);
  addSubMatrix(GG5, G43, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GG7, G43, kk7, nn7, 0, 0, kk5, nn5);
  addSubMatrix(GG5, G43, nn5-kk5, nn5, kk5, 0, kk5+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G43, nn7-kk7, nn7, kk7, 0, kk5+kk7+nn5-kk5, nn7);
  //appendBlockMatrix(GGBar5, GGBar7, GBar47, nn5, nn5, nn7, nn7);
  addSubMatrix(GGBar5, GBar43, kk5, nn5, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar43, kk7, nn7, 0, 0, kk5, nn5);
  addSubMatrix(GGBar5, GBar43, nn5-kk5, nn5, kk5, 0, kk5+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar43, nn7-kk7, nn7, kk7, 0, kk5+kk7+nn5-kk5, nn7);
  appendVector(hh5, hh7, h43, nn5, nn7);
  Q43 = (QQ7+QQ5);
  appendVector(DD5, DD7, D43, kk5, kk7);
  appendBlockMatrix(JJ5, JJ7, J43, kk5, kk5, kk7, kk7);

  // phiprime * phidprime
  int n44 = nn7+nn6; int k44 = kk7+kk6; int **G44; int **GBar44; int *h44; int Q44; int *D44; int **J44;
  G44 = calloc(nn7+nn6,sizeof(int*));
  GBar44 = calloc(nn7+nn6,sizeof(int*));
  h44 = calloc(nn7+nn6,sizeof(int));
  D44 = calloc(kk7+kk6,sizeof(int));
  J44 = calloc(kk7+kk6,sizeof(int*));
  for(i=0; i<nn7+nn6; i++) {
    G44[i] = calloc(nn7+nn6, sizeof(int)); GBar44[i] = calloc(nn7+nn6, sizeof(int));
  }
  for(i=0; i<kk7+kk6; i++)
     J44[i] = calloc(kk7+kk6, sizeof(int));
  //appendBlockMatrix(GG6, GG7, G48, nn6, nn6, nn7, nn7);
  addSubMatrix(GG6, G44, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GG7, G44, kk7, nn7, 0, 0, kk6, nn6);
  addSubMatrix(GG6, G44, nn6-kk6, nn6, kk6, 0, kk6+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G44, nn7-kk7, nn7, kk7, 0, kk6+kk7+nn6-kk6, nn7);
  //appendBlockMatrix(GGBar6, GGBar7, GBar48, nn6, nn6, nn7, nn7);
  addSubMatrix(GGBar6, GBar44, kk6, nn6, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar44, kk7, nn7, 0, 0, kk6, nn6);
  addSubMatrix(GGBar6, GBar44, nn6-kk6, nn6, kk6, 0, kk6+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar44, nn7-kk7, nn7, kk7, 0, kk6+kk7+nn6-kk6, nn7);
  appendVector(hh6, hh7, h44, nn6, nn7);
  Q44 = (QQ7+QQ6);
  appendVector(DD6, DD7, D44, kk6, kk7);
  appendBlockMatrix(JJ6, JJ7, J44, kk6, kk6, kk7, kk7);

  // phidprime * phidprime
  int n45 = nn7+nn7; int k45 = kk7+kk7; int **G45; int **GBar45; int *h45; int Q45; int *D45; int **J45;
  G45 = calloc(nn7+nn7,sizeof(int*));
  GBar45 = calloc(nn7+nn7,sizeof(int*));
  h45 = calloc(nn7+nn7,sizeof(int));
  D45 = calloc(kk7+kk7,sizeof(int));
  J45 = calloc(kk7+kk7,sizeof(int*));
  for(i=0; i<nn7+nn7; i++) {
    G45[i] = calloc(nn7+nn7, sizeof(int)); GBar45[i] = calloc(nn7+nn7, sizeof(int));
  }
  for(i=0; i<kk7+kk7; i++)
     J45[i] = calloc(kk7+kk7, sizeof(int));
  //appendBlockMatrix(GG7, GG7, G49, nn7, nn7, nn7, nn7);
  addSubMatrix(GG7, G45, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GG7, G45, kk7, nn7, 0, 0, kk7, nn7);
  addSubMatrix(GG7, G45, nn7-kk7, nn7, kk7, 0, kk7+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GG7, G45, nn7-kk7, nn7, kk7, 0, kk7+kk7+nn7-kk7, nn7);
  //appendBlockMatrix(GGBar7, GGBar7, GBar49, nn7, nn7, nn7, nn7);
  addSubMatrix(GGBar7, GBar45, kk7, nn7, 0, 0, 0, 0);
  addSubMatrix(GGBar7, GBar45, kk7, nn7, 0, 0, kk7, nn7);
  addSubMatrix(GGBar7, GBar45, nn7-kk7, nn7, kk7, 0, kk7+kk7, 0); // put the out-of-subspace vectors at the end
  addSubMatrix(GGBar7, GBar45, nn7-kk7, nn7, kk7, 0, kk7+kk7+nn7-kk7, nn7);
  appendVector(hh7, hh7, h45, nn7, nn7);
  Q45 = (QQ7+QQ7);
  appendVector(DD7, DD7, D45, kk7, kk7);
  appendBlockMatrix(JJ7, JJ7, J45, kk7, kk7, kk7, kk7);

  // b60 * b66 + b66 * b60
  int n46 = 12; int k46 = 11;
  int (*(G46[])) = { (int[]) {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
  int (*(GBar46[])) = { (int[]) {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
  int h46[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  int Q46 = 4;
  int D46[] = {0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4};
  int (*(J46[])) = { (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};

  // e6 * o6 + e6 * o6
  int n47 = 12; int k47 = 11;
  int (*(G47[])) = { (int[]) {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, (int[]) {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
  int (*(GBar47[])) = { (int[]) {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, (int[]) {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, (int[]) {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
  int h47[] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  int Q47 = 0;
  int D47[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  int (*(J47[])) = { (int[]) {0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, (int[]) {4, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4}, (int[]) {4, 4, 0, 4, 4, 4, 4, 4, 4, 4, 4}, (int[]) {4, 4, 4, 0, 4, 4, 4, 4, 4, 4, 4}, (int[]) {4, 4, 4, 4, 0, 4, 4, 4, 4, 4, 4}, (int[]) {4, 4, 4, 4, 4, 0, 4, 4, 4, 4, 4}, (int[]) {4, 4, 4, 4, 4, 4, 0, 4, 4, 4, 4}, (int[]) {4, 4, 4, 4, 4, 4, 4, 0, 4, 4, 4}, (int[]) {4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 4}, (int[]) {4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4}, (int[]) {4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0}};



  
  int *K; int ***G; int ***GBar; int **h; int *Q; int **D; int ***J;
  double complex Gamma[(int)pow(47,N/12)]; // prefactor in front of resultant state
  G = calloc(pow(47,N/12),sizeof(int*)); GBar = calloc(pow(47,N/12),sizeof(int*));
  h = calloc(pow(47,N/12),sizeof(int*));
  
  J = calloc(pow(47,N/12),sizeof(int*)); D = calloc(pow(47,N/12),sizeof(int*)); Q = calloc(pow(47,N/12),sizeof(int));

  K = calloc(pow(47,N/12), sizeof(int));

  int origK, origQ, *origD;
  int **origJ;
  int **origG, **origGBar;
  int *origh;
  double complex origGamma;

  int combination; // a particular combination from the linear combo of stabilizer states making up the tensor factors multiplied together
  

  for(j=0; j<pow(47,N/12); j++) { // there will be 47^(N/12) combinations when using k=12 tensor factors

    combination = j;

    K[j] = 0.0;
    
    for(k=0; k<N/12; k++) {
      K[j] += (((combination%47)==46)*k47 + ((combination%47)==45)*k46 + ((combination%47)==44)*k45 + ((combination%47)==43)*k44 + ((combination%47)==42)*k43 + ((combination%47)==41)*k42 + ((combination%47)==40)*k41 + ((combination%47)==39)*k40 +
	       ((combination%47)==38)*k39 + ((combination%47)==37)*k38 + ((combination%47)==36)*k37 + ((combination%47)==35)*k36 + ((combination%47)==34)*k35 + ((combination%47)==33)*k34 + ((combination%47)==32)*k33 + ((combination%47)==31)*k32 + ((combination%47)==30)*k31 + ((combination%47)==29)*k30 +
	       ((combination%47)==28)*k29 + ((combination%47)==27)*k28 + ((combination%47)==26)*k27 + ((combination%47)==25)*k26 + ((combination%47)==24)*k25 + ((combination%47)==23)*k24 + ((combination%47)==22)*k23 + ((combination%47)==21)*k22 + ((combination%47)==20)*k21 + ((combination%47)==19)*k20 +
	       ((combination%47)==18)*k19 + ((combination%47)==17)*k18 + ((combination%47)==16)*k17 + ((combination%47)==15)*k16 + ((combination%47)==14)*k15 + ((combination%47)==13)*k14 + ((combination%47)==12)*k13 + ((combination%47)==11)*k12 + ((combination%47)==10)*k11 + ((combination%47)==9)*k10 +
	       ((combination%47)==8)*k9 + ((combination%47)==7)*k8 + ((combination%47)==6)*k7 + ((combination%47)==5)*k6 + ((combination%47)==4)*k5 + ((combination%47)==3)*k4 + ((combination%47)==2)*k3 + ((combination%47)==1)*k2 + ((combination%47)==0)*k1);
      combination /= 47;
    }
    combination = j;

    Gamma[j] = 1.0;

    G[j] = calloc(N, sizeof(int*)); GBar[j] = calloc(N, sizeof(int*));
    h[j] = calloc(N, sizeof(int));

    if(K[j] > 0) {
      J[j] = calloc(K[j], sizeof(int*)); D[j] = calloc(K[j], sizeof(int));
      for(k=0; k<K[j]; k++)
	J[j][k] = calloc(K[j], sizeof(int));
    }

    for(k=0; k<N; k++) {
      G[j][k] = calloc(N, sizeof(int)); GBar[j][k] = calloc(N, sizeof(int));
    }

    int Kcounter = 0; // Kcounter keeps track of the K<=N that we have added already to the G rows etc. for each combination that is indexed by the digits (base 3) of 'j' in that we go through with 'k'
    int Kcombo; // Kcombo stores the k<(n1=n2=n3) dimension of the member of the combination that we are currently adding
    for(k=0; k<N/12; k++) {

      Q[j] += (((combination%47)==46)*Q47 + ((combination%47)==45)*Q46 + ((combination%47)==44)*Q45 + ((combination%47)==43)*Q44 + ((combination%47)==42)*Q43 + ((combination%47)==41)*Q42 + ((combination%47)==40)*Q41 + ((combination%47)==39)*Q40 +
	       ((combination%47)==38)*Q39 + ((combination%47)==37)*Q38 + ((combination%47)==36)*Q37 + ((combination%47)==35)*Q36 + ((combination%47)==34)*Q35 + ((combination%47)==33)*Q34 + ((combination%47)==32)*Q33 + ((combination%47)==31)*Q32 + ((combination%47)==30)*Q31 + ((combination%47)==29)*Q30 +
	       ((combination%47)==28)*Q29 + ((combination%47)==27)*Q28 + ((combination%47)==26)*Q27 + ((combination%47)==25)*Q26 + ((combination%47)==24)*Q25 + ((combination%47)==23)*Q24 + ((combination%47)==22)*Q23 + ((combination%47)==21)*Q22 + ((combination%47)==20)*Q21 + ((combination%47)==19)*Q20 +
	       ((combination%47)==18)*Q19 + ((combination%47)==17)*Q18 + ((combination%47)==16)*Q17 + ((combination%47)==15)*Q16 + ((combination%47)==14)*Q15 + ((combination%47)==13)*Q14 + ((combination%47)==12)*Q13 + ((combination%47)==11)*Q12 + ((combination%47)==10)*Q11 + ((combination%47)==9)*Q10 +
	       ((combination%47)==8)*Q9 + ((combination%47)==7)*Q8 + ((combination%47)==6)*Q7 + ((combination%47)==5)*Q6 + ((combination%47)==4)*Q5 + ((combination%47)==3)*Q4 + ((combination%47)==2)*Q3 + ((combination%47)==1)*Q2 + ((combination%47)==0)*Q1);
      

      Gamma[j] *= (((combination%47)==46)*coeffe6*coeffo6*sqrt(2.0) + ((combination%47)==45)*coeffb60*coeffb66*sqrt(2.0) + ((combination%47)==44)*coeffphidprime*coeffphidprime + ((combination%47)==43)*coeffphiprime*coeffphidprime + ((combination%47)==42)*coeffk6*coeffphidprime + ((combination%47)==41)*coeffo6*coeffphidprime + ((combination%47)==40)*coeffe6*coeffphidprime + ((combination%47)==39)*coeffb66*coeffphidprime + ((combination%47)==38)*coeffb60*coeffphidprime
		   + ((combination%47)==37)*coeffphidprime*coeffphiprime + ((combination%47)==36)*coeffphiprime*coeffphiprime + ((combination%47)==35)*coeffk6*coeffphiprime + ((combination%47)==34)*coeffo6*coeffphiprime + ((combination%47)==33)*coeffe6*coeffphiprime + ((combination%47)==32)*coeffb66*coeffphiprime + ((combination%47)==31)*coeffb60*coeffphiprime
		   + ((combination%47)==30)*coeffphidprime*coeffk6 + ((combination%47)==29)*coeffphiprime*coeffk6 + ((combination%47)==28)*coeffk6*coeffk6 + ((combination%47)==27)*coeffo6*coeffk6 + ((combination%47)==26)*coeffe6*coeffk6 + ((combination%47)==25)*coeffb66*coeffk6 + ((combination%47)==24)*coeffb60*coeffk6
		   + ((combination%47)==23)*coeffphidprime*coeffo6 + ((combination%47)==22)*coeffphiprime*coeffo6 + ((combination%47)==21)*coeffk6*coeffo6 + ((combination%47)==20)*coeffo6*coeffo6  + ((combination%47)==19)*coeffb66*coeffo6 + ((combination%47)==18)*coeffb60*coeffo6
		   + ((combination%47)==17)*coeffphidprime*coeffe6 + ((combination%47)==16)*coeffphiprime*coeffe6 + ((combination%47)==15)*coeffk6*coeffe6 + ((combination%47)==14)*coeffe6*coeffe6 + ((combination%47)==13)*coeffb66*coeffe6 + ((combination%47)==12)*coeffb60*coeffe6
		   + ((combination%47)==11)*coeffphidprime*coeffb66 + ((combination%47)==10)*coeffphiprime*coeffb66 + ((combination%47)==9)*coeffk6*coeffb66 + ((combination%47)==8)*coeffo6*coeffb66 + ((combination%47)==7)*coeffe6*coeffb66 + ((combination%47)==6)*coeffb66*coeffb66
		   + ((combination%47)==5)*coeffphidprime*coeffb60 + ((combination%47)==4)*coeffphiprime*coeffb60 + ((combination%47)==3)*coeffk6*coeffb60 + ((combination%47)==2)*coeffo6*coeffb60 + ((combination%47)==1)*coeffe6*coeffb60 + ((combination%47)==0)*coeffb60*coeffb60);

      Kcombo = (((combination%47)==46)*k47 + ((combination%47)==45)*k46 + ((combination%47)==44)*k45 + ((combination%47)==43)*k44 + ((combination%47)==42)*k43 + ((combination%47)==41)*k42 + ((combination%47)==40)*k41 + ((combination%47)==39)*k40 +
	       ((combination%47)==38)*k39 + ((combination%47)==37)*k38 + ((combination%47)==36)*k37 + ((combination%47)==35)*k36 + ((combination%47)==34)*k35 + ((combination%47)==33)*k34 + ((combination%47)==32)*k33 + ((combination%47)==31)*k32 + ((combination%47)==30)*k31 + ((combination%47)==29)*k30 +
	       ((combination%47)==28)*k29 + ((combination%47)==27)*k28 + ((combination%47)==26)*k27 + ((combination%47)==25)*k26 + ((combination%47)==24)*k25 + ((combination%47)==23)*k24 + ((combination%47)==22)*k23 + ((combination%47)==21)*k22 + ((combination%47)==20)*k21 + ((combination%47)==19)*k20 +
	       ((combination%47)==18)*k19 + ((combination%47)==17)*k18 + ((combination%47)==16)*k17 + ((combination%47)==15)*k16 + ((combination%47)==14)*k15 + ((combination%47)==13)*k14 + ((combination%47)==12)*k13 + ((combination%47)==11)*k12 + ((combination%47)==10)*k11 + ((combination%47)==9)*k10 +
	       ((combination%47)==8)*k9 + ((combination%47)==7)*k8 + ((combination%47)==6)*k7 + ((combination%47)==5)*k6 + ((combination%47)==4)*k5 + ((combination%47)==3)*k4 + ((combination%47)==2)*k3 + ((combination%47)==1)*k2 + ((combination%47)==0)*k1);
      for(l=0; l<Kcombo; l++) {
	// D1 has a different number of rows 'l' than D2 and D3 so you need to use something like 'switch' to check combination%3 without going out of bound of J1
	switch(combination%47) {
	case 0:
	  D[j][Kcounter+l] = D1[l];
	  break;
	case 1:
	  D[j][Kcounter+l] = D2[l];
	  break;
	case 2:
	  D[j][Kcounter+l] = D3[l];
	  break;
	case 3:
	  D[j][Kcounter+l] = D4[l];
	    break;
	case 4:
	  D[j][Kcounter+l] = D5[l];
	  break;
	case 5:
	  D[j][Kcounter+l] = D6[l];
	  break;
	case 6:
	  D[j][Kcounter+l] = D7[l];
	  break;
	case 7:
	  D[j][Kcounter+l] = D8[l];
	  break;
	case 8:
	  D[j][Kcounter+l] = D9[l];
	  break;
	case 9:
	  D[j][Kcounter+l] = D10[l];
	  break;
	case 10:
	  D[j][Kcounter+l] = D11[l];
	  break;
	case 11:
	  D[j][Kcounter+l] = D12[l];
	  break;
	case 12:
	  D[j][Kcounter+l] = D13[l];
	  break;
	case 13:
	  D[j][Kcounter+l] = D14[l];
	    break;
	case 14:
	  D[j][Kcounter+l] = D15[l];
	  break;
	case 15:
	  D[j][Kcounter+l] = D16[l];
	  break;
	case 16:
	  D[j][Kcounter+l] = D17[l];
	  break;
	case 17:
	  D[j][Kcounter+l] = D18[l];
	  break;
	case 18:
	  D[j][Kcounter+l] = D19[l];
	  break;
	case 19:
	  D[j][Kcounter+l] = D20[l];
	  break;
	case 20:
	  D[j][Kcounter+l] = D21[l];
	  break;
	case 21:
	  D[j][Kcounter+l] = D22[l];
	  break;
	case 22:
	  D[j][Kcounter+l] = D23[l];
	  break;
	case 23:
	  D[j][Kcounter+l] = D24[l];
	    break;
	case 24:
	  D[j][Kcounter+l] = D25[l];
	  break;
	case 25:
	  D[j][Kcounter+l] = D26[l];
	  break;
	case 26:
	  D[j][Kcounter+l] = D27[l];
	  break;
	case 27:
	  D[j][Kcounter+l] = D28[l];
	  break;
	case 28:
	  D[j][Kcounter+l] = D29[l];
	  break;
	case 29:
	  D[j][Kcounter+l] = D30[l];
	  break;
	case 30:
	  D[j][Kcounter+l] = D31[l];
	  break;
	case 31:
	  D[j][Kcounter+l] = D32[l];
	  break;
	case 32:
	  D[j][Kcounter+l] = D33[l];
	  break;
	case 33:
	  D[j][Kcounter+l] = D34[l];
	    break;
	case 34:
	  D[j][Kcounter+l] = D35[l];
	  break;
	case 35:
	  D[j][Kcounter+l] = D36[l];
	  break;
	case 36:
	  D[j][Kcounter+l] = D37[l];
	  break;
	case 37:
	  D[j][Kcounter+l] = D38[l];
	  break;
	case 38:
	  D[j][Kcounter+l] = D39[l];
	  break;
	case 39:
	  D[j][Kcounter+l] = D40[l];
	  break;
	case 40:
	  D[j][Kcounter+l] = D41[l];
	  break;
	case 41:
	  D[j][Kcounter+l] = D42[l];
	  break;
	case 42:
	  D[j][Kcounter+l] = D43[l];
	  break;
	case 43:
	  D[j][Kcounter+l] = D44[l];
	    break;
	case 44:
	  D[j][Kcounter+l] = D45[l];
	  break;
	case 45:
	  D[j][Kcounter+l] = D46[l];
	  break;
	case 46:
	  D[j][Kcounter+l] = D47[l];
	  break;
	default:
	  printf("error");
	  return 1;
	  }
	for(m=0; m<Kcombo; m++) {
	  // J1 has a different number of rows 'l' than J2 and J3 so you need to use something like 'switch' to check combination%3 without going out of bound of J1
	  switch(combination%47) {
	  case 0:
	    J[j][Kcounter+l][Kcounter+m] = J1[l][m];
	    break;
	  case 1:
	    J[j][Kcounter+l][Kcounter+m] = J2[l][m];
	    break;
	  case 2:
	    J[j][Kcounter+l][Kcounter+m] = J3[l][m];
	    break;
	  case 3:
	    J[j][Kcounter+l][Kcounter+m] = J4[l][m];
	    break;
	  case 4:
	    J[j][Kcounter+l][Kcounter+m] = J5[l][m];
	    break;
	  case 5:
	    J[j][Kcounter+l][Kcounter+m] = J6[l][m];
	    break;
	  case 6:
	    J[j][Kcounter+l][Kcounter+m] = J7[l][m];
	    break;
	  case 7:
	    J[j][Kcounter+l][Kcounter+m] = J8[l][m];
	    break;
	  case 8:
	    J[j][Kcounter+l][Kcounter+m] = J9[l][m];
	    break;
	  case 9:
	    J[j][Kcounter+l][Kcounter+m] = J10[l][m];
	    break;
	  case 10:
	    J[j][Kcounter+l][Kcounter+m] = J11[l][m];
	    break;
	  case 11:
	    J[j][Kcounter+l][Kcounter+m] = J12[l][m];
	    break;
	  case 12:
	    J[j][Kcounter+l][Kcounter+m] = J13[l][m];
	    break;
	  case 13:
	    J[j][Kcounter+l][Kcounter+m] = J14[l][m];
	    break;
	  case 14:
	    J[j][Kcounter+l][Kcounter+m] = J15[l][m];
	    break;
	  case 15:
	    J[j][Kcounter+l][Kcounter+m] = J16[l][m];
	    break;
	  case 16:
	    J[j][Kcounter+l][Kcounter+m] = J17[l][m];
	    break;
	  case 17:
	    J[j][Kcounter+l][Kcounter+m] = J18[l][m];
	    break;
	  case 18:
	    J[j][Kcounter+l][Kcounter+m] = J19[l][m];
	    break;
	  case 19:
	    J[j][Kcounter+l][Kcounter+m] = J20[l][m];
	    break;
	  case 20:
	    J[j][Kcounter+l][Kcounter+m] = J21[l][m];
	    break;
	  case 21:
	    J[j][Kcounter+l][Kcounter+m] = J22[l][m];
	    break;
	  case 22:
	    J[j][Kcounter+l][Kcounter+m] = J23[l][m];
	    break;
	  case 23:
	    J[j][Kcounter+l][Kcounter+m] = J24[l][m];
	    break;
	  case 24:
	    J[j][Kcounter+l][Kcounter+m] = J25[l][m];
	    break;
	  case 25:
	    J[j][Kcounter+l][Kcounter+m] = J26[l][m];
	    break;
	  case 26:
	    J[j][Kcounter+l][Kcounter+m] = J27[l][m];
	    break;
	  case 27:
	    J[j][Kcounter+l][Kcounter+m] = J28[l][m];
	    break;
	  case 28:
	    J[j][Kcounter+l][Kcounter+m] = J29[l][m];
	    break;
	  case 29:
	    J[j][Kcounter+l][Kcounter+m] = J30[l][m];
	    break;
	  case 30:
	    J[j][Kcounter+l][Kcounter+m] = J31[l][m];
	    break;
	  case 31:
	    J[j][Kcounter+l][Kcounter+m] = J32[l][m];
	    break;
	  case 32:
	    J[j][Kcounter+l][Kcounter+m] = J33[l][m];
	    break;
	  case 33:
	    J[j][Kcounter+l][Kcounter+m] = J34[l][m];
	    break;
	  case 34:
	    J[j][Kcounter+l][Kcounter+m] = J35[l][m];
	    break;
	  case 35:
	    J[j][Kcounter+l][Kcounter+m] = J36[l][m];
	    break;
	  case 36:
	    J[j][Kcounter+l][Kcounter+m] = J37[l][m];
	    break;
	  case 37:
	    J[j][Kcounter+l][Kcounter+m] = J38[l][m];
	    break;
	  case 38:
	    J[j][Kcounter+l][Kcounter+m] = J39[l][m];
	    break;
	  case 39:
	    J[j][Kcounter+l][Kcounter+m] = J40[l][m];
	    break;
	  case 40:
	    J[j][Kcounter+l][Kcounter+m] = J41[l][m];
	    break;
	  case 41:
	    J[j][Kcounter+l][Kcounter+m] = J42[l][m];
	    break;
	  case 42:
	    J[j][Kcounter+l][Kcounter+m] = J43[l][m];
	    break;
	  case 43:
	    J[j][Kcounter+l][Kcounter+m] = J44[l][m];
	    break;
	  case 44:
	    J[j][Kcounter+l][Kcounter+m] = J45[l][m];
	    break;
	  case 45:
	    J[j][Kcounter+l][Kcounter+m] = J46[l][m];
	    break;
	  case 46:
	    J[j][Kcounter+l][Kcounter+m] = J47[l][m];
	    break;
	  default:
	    printf("error");
	    return 1;
	  }
	}
      }

      for(l=0; l<n1; l++) { // assuming n1=n2=n3
	h[j][k*n1+l] = (((combination%47)==46)*h47[l] + ((combination%47)==45)*h46[l] + ((combination%47)==44)*h45[l] + ((combination%47)==43)*h44[l] + ((combination%47)==42)*h43[l] + ((combination%47)==41)*h42[l] + ((combination%47)==40)*h41[l] + ((combination%47)==39)*h40[l] +
			((combination%47)==38)*h39[l] + ((combination%47)==37)*h38[l] + ((combination%47)==36)*h37[l] + ((combination%47)==35)*h36[l] + ((combination%47)==34)*h35[l] + ((combination%47)==33)*h34[l] + ((combination%47)==32)*h33[l] + ((combination%47)==31)*h32[l] + ((combination%47)==30)*h31[l] + ((combination%47)==29)*h30[l] +
			((combination%47)==28)*h29[l] + ((combination%47)==27)*h28[l] + ((combination%47)==26)*h27[l] + ((combination%47)==25)*h26[l] + ((combination%47)==24)*h25[l] + ((combination%47)==23)*h24[l] + ((combination%47)==22)*h23[l] + ((combination%47)==21)*h22[l] + ((combination%47)==20)*h21[l] + ((combination%47)==19)*h20[l] +
			((combination%47)==18)*h19[l] + ((combination%47)==17)*h18[l] + ((combination%47)==16)*h17[l] + ((combination%47)==15)*h16[l] + ((combination%47)==14)*h15[l] + ((combination%47)==13)*h14[l] + ((combination%47)==12)*h13[l] + ((combination%47)==11)*h12[l] + ((combination%47)==10)*h11[l] + ((combination%47)==9)*h10[l] +
			((combination%47)==8)*h9[l] + ((combination%47)==7)*h8[l] + ((combination%47)==6)*h7[l] + ((combination%47)==5)*h6[l] + ((combination%47)==4)*h5[l] + ((combination%47)==3)*h4[l] + ((combination%47)==2)*h3[l] + ((combination%47)==1)*h2[l] + ((combination%47)==0)*h1[l]);
      }
      // only filling the K[j] first rows of G and GBar here corresponding to the basis for D and J
      for(l=0; l<Kcombo; l++) {
	for(m=0; m<n1; m++) { // assuming n1=n2=n3
	  G[j][Kcounter+l][k*n1+m] = (((combination%47)==46)*G47[l][m] + ((combination%47)==45)*G46[l][m] + ((combination%47)==44)*G45[l][m] + ((combination%47)==43)*G44[l][m] + ((combination%47)==42)*G43[l][m] + ((combination%47)==41)*G42[l][m] + ((combination%47)==40)*G41[l][m] + ((combination%47)==39)*G40[l][m] +
				      ((combination%47)==38)*G39[l][m] + ((combination%47)==37)*G38[l][m] + ((combination%47)==36)*G37[l][m] + ((combination%47)==35)*G36[l][m] + ((combination%47)==34)*G35[l][m] + ((combination%47)==33)*G34[l][m] + ((combination%47)==32)*G33[l][m] + ((combination%47)==31)*G32[l][m] + ((combination%47)==30)*G31[l][m] + ((combination%47)==29)*G30[l][m] +
				      ((combination%47)==28)*G29[l][m] + ((combination%47)==27)*G28[l][m] + ((combination%47)==26)*G27[l][m] + ((combination%47)==25)*G26[l][m] + ((combination%47)==24)*G25[l][m] + ((combination%47)==23)*G24[l][m] + ((combination%47)==22)*G23[l][m] + ((combination%47)==21)*G22[l][m] + ((combination%47)==20)*G21[l][m] + ((combination%47)==19)*G20[l][m] +
				      ((combination%47)==18)*G19[l][m] + ((combination%47)==17)*G18[l][m] + ((combination%47)==16)*G17[l][m] + ((combination%47)==15)*G16[l][m] + ((combination%47)==14)*G15[l][m] + ((combination%47)==13)*G14[l][m] + ((combination%47)==12)*G13[l][m] + ((combination%47)==11)*G12[l][m] + ((combination%47)==10)*G11[l][m] + ((combination%47)==9)*G10[l][m] +
				      ((combination%47)==8)*G9[l][m] + ((combination%47)==7)*G8[l][m] + ((combination%47)==6)*G7[l][m] + ((combination%47)==5)*G6[l][m] + ((combination%47)==4)*G5[l][m] + ((combination%47)==3)*G4[l][m] + ((combination%47)==2)*G3[l][m] + ((combination%47)==1)*G2[l][m] + ((combination%47)==0)*G1[l][m]);
	  GBar[j][Kcounter+l][k*n1+m] = (((combination%47)==46)*GBar47[l][m] + ((combination%47)==45)*GBar46[l][m] + ((combination%47)==44)*GBar45[l][m] + ((combination%47)==43)*GBar44[l][m] + ((combination%47)==42)*GBar43[l][m] + ((combination%47)==41)*GBar42[l][m] + ((combination%47)==40)*GBar41[l][m] + ((combination%47)==39)*GBar40[l][m] +
					 ((combination%47)==38)*GBar39[l][m] + ((combination%47)==37)*GBar38[l][m] + ((combination%47)==36)*GBar37[l][m] + ((combination%47)==35)*GBar36[l][m] + ((combination%47)==34)*GBar35[l][m] + ((combination%47)==33)*GBar34[l][m] + ((combination%47)==32)*GBar33[l][m] + ((combination%47)==31)*GBar32[l][m] + ((combination%47)==30)*GBar31[l][m] + ((combination%47)==29)*GBar30[l][m] +
					 ((combination%47)==28)*GBar29[l][m] + ((combination%47)==27)*GBar28[l][m] + ((combination%47)==26)*GBar27[l][m] + ((combination%47)==25)*GBar26[l][m] + ((combination%47)==24)*GBar25[l][m] + ((combination%47)==23)*GBar24[l][m] + ((combination%47)==22)*GBar23[l][m] + ((combination%47)==21)*GBar22[l][m] + ((combination%47)==20)*GBar21[l][m] + ((combination%47)==19)*GBar20[l][m] +
					 ((combination%47)==18)*GBar19[l][m] + ((combination%47)==17)*GBar18[l][m] + ((combination%47)==16)*GBar17[l][m] + ((combination%47)==15)*GBar16[l][m] + ((combination%47)==14)*GBar15[l][m] + ((combination%47)==13)*GBar14[l][m] + ((combination%47)==12)*GBar13[l][m] + ((combination%47)==11)*GBar12[l][m] + ((combination%47)==10)*GBar11[l][m] + ((combination%47)==9)*GBar10[l][m] +
					 ((combination%47)==8)*GBar9[l][m] + ((combination%47)==7)*GBar8[l][m] + ((combination%47)==6)*GBar7[l][m] + ((combination%47)==5)*GBar6[l][m] + ((combination%47)==4)*GBar5[l][m] + ((combination%47)==3)*GBar4[l][m] + ((combination%47)==2)*GBar3[l][m] + ((combination%47)==1)*GBar2[l][m] + ((combination%47)==0)*GBar1[l][m]);
	}
      }
      Kcounter = Kcounter + Kcombo;
      
      /* printf("intermediate G[%d]:\n", j); */
      /* printMatrix(G[j], N, N); */
      /* printf("intermediate GBar[%d]:\n", j); */
      /* printMatrix(GBar[j], N, N); */
      //memcpy(origG[j][k], G[j][k], N*sizeof(int)); memcpy(origGBar[j][k], GBar[j][k], N*sizeof(int));

      //memcpy(origJ[j][k], J[j][k], K[j]*sizeof(int));
      
      combination /= 47; // shift to the right by one (in base-47 arithmetic)
    }
    //printf("!\n");

    // now need to fill the N-Kcounter remaining rows of G and GBar that are outside the spanning basis states of D and J
    combination = j;
    for(k=0; k<(N/12); k++) {
      Kcombo = (((combination%47)==46)*k47 + ((combination%47)==45)*k46 + ((combination%47)==44)*k45 + ((combination%47)==43)*k44 + ((combination%47)==42)*k43 + ((combination%47)==41)*k42 + ((combination%47)==40)*k41 + ((combination%47)==39)*k40 +
	       ((combination%47)==38)*k39 + ((combination%47)==37)*k38 + ((combination%47)==36)*k37 + ((combination%47)==35)*k36 + ((combination%47)==34)*k35 + ((combination%47)==33)*k34 + ((combination%47)==32)*k33 + ((combination%47)==31)*k32 + ((combination%47)==30)*k31 + ((combination%47)==29)*k30 +
	       ((combination%47)==28)*k29 + ((combination%47)==27)*k28 + ((combination%47)==26)*k27 + ((combination%47)==25)*k26 + ((combination%47)==24)*k25 + ((combination%47)==23)*k24 + ((combination%47)==22)*k23 + ((combination%47)==21)*k22 + ((combination%47)==20)*k21 + ((combination%47)==19)*k20 +
	       ((combination%47)==18)*k19 + ((combination%47)==17)*k18 + ((combination%47)==16)*k17 + ((combination%47)==15)*k16 + ((combination%47)==14)*k15 + ((combination%47)==13)*k14 + ((combination%47)==12)*k13 + ((combination%47)==11)*k12 + ((combination%47)==10)*k11 + ((combination%47)==9)*k10 +
	       ((combination%47)==8)*k9 + ((combination%47)==7)*k8 + ((combination%47)==6)*k7 + ((combination%47)==5)*k6 + ((combination%47)==4)*k5 + ((combination%47)==3)*k4 + ((combination%47)==2)*k3 + ((combination%47)==1)*k2 + ((combination%47)==0)*k1);
      //printf("Kcounter=%d\n", Kcounter);
      // G and GBar rows that are outside the first 'k' spanning basis states
      for(l=Kcombo; l<n1; l++) { // assuming n1=n2=n3
	//printf("l=%d\n", l);
      	for(m=0; m<n1; m++) { // assuming n1=n2=n3
	  /* printf("m=%d\n", m); */
	  /* printf("Kcounter+l=%d\n", Kcounter+l); */
	  /* printf("k*n1+m=%d\n", k*n1+m); */
      	  G[j][Kcounter+l-Kcombo][k*n1+m] = (((combination%47)==46)*G47[l][m] + ((combination%47)==45)*G46[l][m] + ((combination%47)==44)*G45[l][m] + ((combination%47)==43)*G44[l][m] + ((combination%47)==42)*G43[l][m] + ((combination%47)==41)*G42[l][m] + ((combination%47)==40)*G41[l][m] + ((combination%47)==39)*G40[l][m] +
				      ((combination%47)==38)*G39[l][m] + ((combination%47)==37)*G38[l][m] + ((combination%47)==36)*G37[l][m] + ((combination%47)==35)*G36[l][m] + ((combination%47)==34)*G35[l][m] + ((combination%47)==33)*G34[l][m] + ((combination%47)==32)*G33[l][m] + ((combination%47)==31)*G32[l][m] + ((combination%47)==30)*G31[l][m] + ((combination%47)==29)*G30[l][m] +
				      ((combination%47)==28)*G29[l][m] + ((combination%47)==27)*G28[l][m] + ((combination%47)==26)*G27[l][m] + ((combination%47)==25)*G26[l][m] + ((combination%47)==24)*G25[l][m] + ((combination%47)==23)*G24[l][m] + ((combination%47)==22)*G23[l][m] + ((combination%47)==21)*G22[l][m] + ((combination%47)==20)*G21[l][m] + ((combination%47)==19)*G20[l][m] +
				      ((combination%47)==18)*G19[l][m] + ((combination%47)==17)*G18[l][m] + ((combination%47)==16)*G17[l][m] + ((combination%47)==15)*G16[l][m] + ((combination%47)==14)*G15[l][m] + ((combination%47)==13)*G14[l][m] + ((combination%47)==12)*G13[l][m] + ((combination%47)==11)*G12[l][m] + ((combination%47)==10)*G11[l][m] + ((combination%47)==9)*G10[l][m] +
				      ((combination%47)==8)*G9[l][m] + ((combination%47)==7)*G8[l][m] + ((combination%47)==6)*G7[l][m] + ((combination%47)==5)*G6[l][m] + ((combination%47)==4)*G5[l][m] + ((combination%47)==3)*G4[l][m] + ((combination%47)==2)*G3[l][m] + ((combination%47)==1)*G2[l][m] + ((combination%47)==0)*G1[l][m]);
      	  GBar[j][Kcounter+l-Kcombo][k*n1+m] = (((combination%47)==46)*GBar47[l][m] + ((combination%47)==45)*GBar46[l][m] + ((combination%47)==44)*GBar45[l][m] + ((combination%47)==43)*GBar44[l][m] + ((combination%47)==42)*GBar43[l][m] + ((combination%47)==41)*GBar42[l][m] + ((combination%47)==40)*GBar41[l][m] + ((combination%47)==39)*GBar40[l][m] +
					 ((combination%47)==38)*GBar39[l][m] + ((combination%47)==37)*GBar38[l][m] + ((combination%47)==36)*GBar37[l][m] + ((combination%47)==35)*GBar36[l][m] + ((combination%47)==34)*GBar35[l][m] + ((combination%47)==33)*GBar34[l][m] + ((combination%47)==32)*GBar33[l][m] + ((combination%47)==31)*GBar32[l][m] + ((combination%47)==30)*GBar31[l][m] + ((combination%47)==29)*GBar30[l][m] +
					 ((combination%47)==28)*GBar29[l][m] + ((combination%47)==27)*GBar28[l][m] + ((combination%47)==26)*GBar27[l][m] + ((combination%47)==25)*GBar26[l][m] + ((combination%47)==24)*GBar25[l][m] + ((combination%47)==23)*GBar24[l][m] + ((combination%47)==22)*GBar23[l][m] + ((combination%47)==21)*GBar22[l][m] + ((combination%47)==20)*GBar21[l][m] + ((combination%47)==19)*GBar20[l][m] +
					 ((combination%47)==18)*GBar19[l][m] + ((combination%47)==17)*GBar18[l][m] + ((combination%47)==16)*GBar17[l][m] + ((combination%47)==15)*GBar16[l][m] + ((combination%47)==14)*GBar15[l][m] + ((combination%47)==13)*GBar14[l][m] + ((combination%47)==12)*GBar13[l][m] + ((combination%47)==11)*GBar12[l][m] + ((combination%47)==10)*GBar11[l][m] + ((combination%47)==9)*GBar10[l][m] +
					 ((combination%47)==8)*GBar9[l][m] + ((combination%47)==7)*GBar8[l][m] + ((combination%47)==6)*GBar7[l][m] + ((combination%47)==5)*GBar6[l][m] + ((combination%47)==4)*GBar5[l][m] + ((combination%47)==3)*GBar4[l][m] + ((combination%47)==2)*GBar3[l][m] + ((combination%47)==1)*GBar2[l][m] + ((combination%47)==0)*GBar1[l][m]);
      	}
      }
      Kcounter = Kcounter + (n1-Kcombo);

      /* printf("intermediate G[%d]:\n", j); */
      /* printMatrix(G[j], N, N); */
      /* printf("intermediate GBar[%d]:\n", j); */
      /* printMatrix(GBar[j], N, N); */
      
      combination /= 47;
    }

    /*printf("G[%d]:\n", j);
    printMatrix(G[j], N, N);
    printf("GBar[%d]:\n", j);
    printMatrix(GBar[j], N, N);

    printf("h[%d]:\n", j);
    printVector(h[j], N);

    printf("J[%d]:\n", j);
    printMatrix(J[j], K[j], K[j]);
    
    printf("D[%d]:\n", j);
    printVector(D[j], K[j]);

    printf("Q[%d]=%d\n", j, Q[j]);*/

  }
  //exit(0);

  while(readPaulicoeffs(&omega[Paulicounter], alpha[Paulicounter], beta[Paulicounter], gamma[Paulicounter], delta[Paulicounter], N)) {

    if((Paulicounter+1) > N) {
      printf("Error: Number of Paulis is greater than N!\n");
      return 1;
    }
    
    // Let's break up the Ys into Xs and Zs in the order Z X, as required to pass to measurepauli()
    // Y_i = -I*Z*X
    for(i=0; i<N; i++) {
      if(delta[Paulicounter][i]){
	omega[Paulicounter] += 3; // -I = I^3
	beta[Paulicounter][i] = delta[Paulicounter][i];
	gamma[Paulicounter][i] = delta[Paulicounter][i];
      }
    }

    /*printf("*******\n");
    printf("*******\n");
    printf("omega=%d\n", omega);
    printf("X:\n");
    printVector(gamma, N);
    printf("Z:\n");
    printVector(beta, N);
    printf("*******\n");
    printf("*******\n");*/

    //for(j=0; j<pow(47,N/12); j++) { // the kets

      /*printf("========\n");
      printf("before:\n");
      printf("K=%d\n", K[j]);
      printf("h:\n");
      printVector(h[j], N);
      printf("Gamma[%d]=%lf+%lf\n", j, creal(Gamma[j]), cimag(Gamma[j]));
      printf("G:\n");
      printMatrix(G[j], N, N);
      printf("GBar:\n");
      printMatrix(GBar[j], N, N);
      printf("Q=%d\n", Q[j]);
      printf("D:\n");
      printVector(D[j], K[j]);
      printf("J:\n");
      printMatrix(J[j], K[j], K[j]);*/
      //Gamma[j] *= measurepauli(N, &K[j], h[j], G[j], GBar[j], &Q[j], &D[j], &J[j], omega, gamma, beta);
      /*printf("\nafter:\n");
      printf("K=%d\n", K[j]);
      printf("h:\n");
      printVector(h[j], N);
      printf("Gamma[%d]=%lf+%lf\n", j, creal(Gamma[j]), cimag(Gamma[j]));
      printf("G:\n");
      printMatrix(G[j], N, N);
      printf("GBar:\n");
      printMatrix(GBar[j], N, N);
      printf("Q=%d\n", Q[j]);
      printf("D:\n");
      printVector(D[j], K[j]);
      printf("J:\n");
      printMatrix(J[j], K[j], K[j]);*/

    //}

    Paulicounter++;
  }

  double complex amplitude = 0.0 + 0.0*I;
  for(i=0; i<NUMSTABSTATESAMPLES; i++) { // the bras
    //printf("i=%d\n", i);

    randomstabilizerstate(N, &origK, &origh, &origG, &origGBar, &origQ, &origD, &origJ, Pd);

    origGamma = 1.0 + 0.0*I;
    
    for(k=0; k<Paulicounter; k++) {
      origGamma *= measurepauli(N, &origK, origh, origG, origGBar, &origQ, &origD, &origJ, omega[k], gamma[k], beta[k]);
      //printf("k=%d\n", k);
  }
    /*printf("origK=%d\n", origK);
    printf("origG:\n");
    printMatrix(origG, N, N);
    printf("origGBar:\n");
    printMatrix(origGBar, N, N);
    printf("origh:\n");
    printVector(origh, N);*/

    double complex stabstateaverage = 0.0 + 0.0*I;
    
    for(j=0; j<pow(47,N/12); j++) {
      //printf("j=%d\n", j);
      double complex newamplitude = innerproduct(N, K[j], h[j], G[j], GBar[j], Q[j], D[j], J[j], N, origK, origh, origG, origGBar, origQ, origD, origJ);
      stabstateaverage = stabstateaverage + origGamma*Gamma[j]*newamplitude;
    }
    amplitude = amplitude + conj(stabstateaverage)*stabstateaverage/((double)(NUMSTABSTATESAMPLES))*pow(2.0,T);

    deallocate_mem(&origG, N);
    deallocate_mem(&origGBar, N);
    free(origh);
    deallocate_mem(&origJ, origK);
    free(origD);
  }

  printf("amplitude:\n");
  if(creal(amplitude+ZEROTHRESHOLD)>0)
    printf("%.10lf %c %.10lf I\n", cabs(creal(amplitude)), cimag(amplitude+ZEROTHRESHOLD)>0?'+':'-' , cabs(cimag(amplitude)));
  else
    printf("%.10lf %c %.10lf I\n", creal(amplitude), cimag(amplitude+ZEROTHRESHOLD)>0?'+':'-' , cabs(cimag(amplitude)));
  
  

  for(i=0; i<PdN; i++) 
    free(Pd[i]);
  free(Pd);

  return 0;
}

int readPaulicoeffs(int *omega, int *alpha, int *beta, int *gamma, int *delta, int numqubits)
{
    
  int newomega, newalpha, newbeta, newgamma, newdelta;
  int i;

  if(scanf("%d", &newomega) != EOF) {
    *omega = newomega;
    for(i=0; i<numqubits; i++) {
      if(scanf("%d %d %d %d", &newalpha, &newbeta, &newgamma, &newdelta) == EOF) {
	printf("Error: Too few input coeffs!\n");
	exit(0);
      }
      if(newalpha+newbeta+newgamma+newdelta > 1) {
	printf("Error: Too many coefficients are non-zero at Pauli %d!\n", i);
	exit(0);
      }
      alpha[i] = newalpha; beta[i] = newbeta; gamma[i] = newgamma; delta[i] = newdelta;
    }
    return 1;
  } else
    return 0;
    
}
