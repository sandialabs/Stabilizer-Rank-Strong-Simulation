#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "matrix.h"


int** addMatrix(int **A, int **B, int rows, int cols)
{
  int i, j;

  int** C;

  C = calloc(cols, sizeof(int*));
  for(i=0; i<cols; i++)
    C[i] = calloc(rows, sizeof(int));

  for(i=0; i<rows; i++)
    for(j=0; j<cols; j++)
      C[i][j] = A[i][j] + B[i][j];

  return C;
}

void addMatrixMod(int **A, int **B, int **C, int rows, int cols, int mod)
{
  int i, j;

  for(i=0; i<rows; i++)
    for(j=0; j<cols; j++)
      C[i][j] = (A[i][j] + B[i][j])%mod;

  return;
}

void addVectorMod(int *A, int *B, int *C, int length, int mod)
{
  int i;

  for(i=0; i<length; i++)
    C[i] = (A[i] + B[i])%mod;

  return;
}

void scalarmultMatrix(int scalar, int **a, int **b, int rows, int cols)
{
  int i, j;

  //b = calloc(cols, sizeof(int*));
  //for(i=0; i<cols; i++)
  //  b[i] = calloc(rows, sizeof(int));

  for(i=0; i<rows; i++)
    for(j=0; j<cols; j++)
      b[i][j] = scalar*a[i][j];

}

int trace(int **a, int rows, int cols)
{
  int i;
  int tr = 0.0;

  for(i=0; i<rows; i++)
    tr += a[i][i];

  return tr;
}

// b = a^T
void transp(int **a, int **b, int rows, int cols)
{
  int i, j;

  for(i=0; i<cols; i++) {
    for(j=0; j<rows; j++)
      b[i][j] = a[j][i];
  }    

}

void printVector(int* a, int length)
{
  int i;
  printf("Vector[%d]\n", length);
  for(i=0; i<length; i++)
    printf("%d ", a[i]);
  if(length>0)
    printf("\n");
  
}

void printMatrix(int** a, int rows, int cols)
{
  int i, j;
  printf("Matrix[%d][%d]\n", rows, cols);
  for(i=0; i<rows; i++) {
    for(j=0; j<cols; j++) {
      printf("%d ", a[i][j]);
    }
    printf("\n");
  }
}

int** multMatrix(int **A, int **B, int ro1, int co1, int ro2, int co2)
{
  int i, j, k;
  int **C;
  C = calloc(ro1, sizeof(int*));
  for(i=0; i<ro1; i++)
    C[i] = calloc(co2, sizeof(int));
  
  for(i=0; i<ro1; i++) {
    for(j=0; j<co2; j++) {
      C[i][j] = 0;
      for(k=0; k<co1; k++)
        C[i][j] += A[i][k] * B[k][j];
    }
  }

  return C;
}

// A times B = C
void multMatrixMod(int **A, int **B, int **C, int ro1, int co1, int ro2, int co2, int mod)
{
  int i, j, k, tmp;

  for(i=0; i<ro1; i++) {
    for(j=0; j<co2; j++) {
      tmp = 0;
      for(k=0; k<co1; k++)
        tmp += (A[i][k] * B[k][j]);
      C[i][j] = tmp%mod;
    }
  }

}

int** outerMatrix(int **A, int **B, int ro1, int co1, int ro2, int co2)
{
  int i, j, k, l;
  int **C;
  C = calloc(ro1*ro2, sizeof(int*));
  for(i=0; i<ro1*ro2; i++)
    C[i] = calloc(co1*co2, sizeof(int));

  for(i=0; i<ro1; i++)
    for(j=0; j<ro2; j++)
      for(k=0; k<co1; k++)
	for(l=0; l<co2; l++) {
	  C[j+ro2*i][l+co2*k] = A[i][k]* B[j][l];
	}

  return C;
}

void outerMatrixMod(int **A, int **B, int **C, int ro1, int co1, int ro2, int co2, int mod)
{
  int i, j, k, l;
  //int **C;
  //C = calloc(ro1*ro2, sizeof(int*));
  //for(i=0; i<ro1*ro2; i++)
  //  C[i] = calloc(co1*co2, sizeof(int));

  for(i=0; i<ro1; i++)
    for(j=0; j<ro2; j++)
      for(k=0; k<co1; k++)
	for(l=0; l<co2; l++) {
	  C[j+ro2*i][l+co2*k] = (A[i][k]* B[j][l])%mod;
	}

}

void outerVectorMod(int *A, int *B, int *C, int ro1, int ro2, int mod)
{
  int i, j;

  for(i=0; i<ro1; i++)
    for(j=0; j<ro2; j++)
      C[j+ro2*i]= (A[i]* B[j])%mod;

}

void addSubMatrix(int **A, int **B, int ro1, int co1, int rooff1, int cooff1, int rooff2, int cooff2)
{
  // rooff1 is row offset to start range ro1 in first matrix etc.
  int i, j;

  for(i=0; i<ro1; i++)
    for(j=0; j<co1; j++)
      B[rooff2+i][cooff2+j] = A[rooff1+i][cooff1+j];

}

void appendBlockMatrix(int **A, int **B, int **C, int ro1, int co1, int ro2, int co2)
{
  // rooff1 is row offset to start range ro1 in first matrix etc.
  int i, j;

  for(i=0; i<ro1; i++)
    for(j=0; j<co1; j++)
      C[i][j] = A[i][j];

  for(i=0; i<ro2; i++)
    for(j=0; j<co2; j++)
      C[ro1+i][co1+j] = B[i][j];
  
}


void appendVector(int *A, int *B, int *C, int ro1, int ro2)
{
  int i;

  for(i=0; i<ro1; i++)
    C[i] = A[i];
  for(i=0; i<ro2; i++)
    C[ro1+i] = B[i];

}


int dotProductMod(int *a, int *b, int length, int mod)
{
  int i;
  int dotproduct = 0;

  for(i=0; i<length; i++)
    dotproduct += a[i]*b[i];

  return(dotproduct%mod);
}


void deallocate_mem(int ***arr, int rows)
{
  int i;
  for(i=0; i<rows; i++)
    free((*arr)[i]);
  free(*arr);
}
