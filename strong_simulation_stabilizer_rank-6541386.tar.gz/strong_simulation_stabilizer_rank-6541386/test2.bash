#!/bin/bash
# simple Bash diagnostic script to check if non-zero relative error stabilizer rank code works

# choose the number of qubits and T gates on those qubits
# NOTE: numqubits must be a multiple of your gauss sum tensor multiple!
# e.g. if you test gausssums_multipleof6 then numqubits=6*n for some integer n
numqubits=6
numTgates=6

numrandomsteps=1000000 #10000 # number of random steps when generating Paulis

# number of random stabilizer states to use for stochastic sampling
numsamples=1000

# since this is a stochastic calculation, we need a threshold to determine when the calculation is withing close enough relative error 
threshold=0.005 # absolute value threshold difference between computed and exact value

numruns=100

echo "Starting test of $numruns random $numqubits-Pauli expectation values calculated by averaging $numsamples random stabilizer states and comparing to threshold $threshold..."

for i in $(seq 1 $numruns)
do
# sleep for 1 second for the pseudorandom number generator
sleep 1; a=$(stdbuf -oL ./randominputcommutingHermitianPauli2 $numqubits $numTgates $numrandomsteps > inputPauli.txt && ./strongsim_relerr $numsamples < inputPauli.txt | tail -1)
b=$(stdbuf -oL ./multipauli < inputPauli.txt | tail -n1)
are=$(echo "$a" | cut -f 1 -d " " | cut -c 1-5);
aim=$(echo "$a" | cut -f 3 -d " " | cut -c 1-5); aimsign=$(echo $a | cut -f 2 -d " "); bimsign=$(echo $b | cut -f 2 -d " ");
bre=$(echo "$b" | cut -f 1 -d " " | cut -c 1-5);
bim=$(echo "$b" | cut -f 3 -d " " | cut -c 1-5); echo "$i: $are $aimsign $aim and $bre $bimsign $bim"
rediff=$( printf 'sqrt((%f - %f)^2)\n' "$are" "$bre" | bc -l )
imdiff=$( printf 'sqrt((%f - %f)^2)\n' "$aim" "$bim" | bc -l )
if (( $(echo "$rediff < $threshold" |bc -l) )) && (( $(echo "$imdiff < $threshold" |bc -l) ))
then
    if (( $(echo "$bim < $threshold" |bc -l) )) || [ "$aimsign" == "$bimsign" ]
    then
	continue
    else
	echo "NOT EQUAL!"
	exit
    fi
  else
    echo "NOT EQUAL!"
    exit
fi
done
echo "Test passed!"
