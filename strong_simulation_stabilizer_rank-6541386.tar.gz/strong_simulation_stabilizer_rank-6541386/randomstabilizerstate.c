#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>

#include "lapacke.h"
#include "matrix.h"
#include "shrinkstar.h"

#include "randomstabilizerstate.h"

#define ZEROTHRESHOLD (0.00000001)

// Note: Make sure you seed the random number generator before calling this!
// i.e. srand((unsigned)time(NULL));
void randomstabilizerstate(int n, int* k, int** h, int*** G, int*** GBar, int* Q, int** D, int*** J, double** Pd)
{
  // vector and matrix pointers should all be passed unallocated! (no freeing of memory performed)
  
  float *randomX, *randomXcopy; // d*n matrix that is in array-form for LAPACKE
  float *randomXsingvals; // singular values of randomX
  float *U, *VT, *superb;
  int d;

  int i, j;

  //srand((unsigned)time(NULL));

  double randPd = (double)rand()/(double)(RAND_MAX);

  double cumprob = 0.0;
  for(i=0;i<n+1;i++) {
    cumprob += Pd[n-1][i]; // cumprob goes up to 1.0 once you count all Pd[n][0:n+1]
    if(cumprob > randPd) {
      d = i;
      break;
    }
    d=i;
  }
  //d = rand()%(n+1);
  //printf("d=%d total=%f randPd=%f\n", d, total, randPd);
  //printf("!!!d=%d\n", d);
  
  *k = n; // we will get it to be k=n-d by caling shrinkstar d times below
  
  randomX = calloc(n*d,sizeof(float));
  randomXcopy = calloc(n*d,sizeof(float));
  randomXsingvals = calloc(d,sizeof(float));
  superb = calloc((d),sizeof(float));
  U = calloc((d*d),sizeof(float));
  VT = calloc((n*n),sizeof(float));

  int info;
  int numsingvals = -1;

  while(numsingvals != d) {
    for(i=0; i<d; i++) {
      for(j=0; j<n; j++) {
	randomX[i*n+j] = (float)(rand()%2);
	randomXcopy[i*n+j] = randomX[i*n+j];
	//printf("%1.0f ", randomX[i*n+j]);
      }
      //printf("\n");
    }

    info = LAPACKE_sgesvd( LAPACK_ROW_MAJOR, 'N', 'N', d, n, randomXcopy, n, randomXsingvals, U, n, VT, n, superb );

    numsingvals = 0;
  
    for(i=0; i<d; i++) {
      if(fabs(randomXsingvals[i]) >= ZEROTHRESHOLD)
	numsingvals++;
    }

    //printf("Number of singular values: %d\n", numsingvals);
  }

  *G = calloc(n, sizeof(int*)); *GBar = calloc(n, sizeof(int*));
  
  *h = calloc(n, sizeof(int));

  for(i=0; i<n; i++) {
    (*G)[i] = calloc(n, sizeof(int));
    (*GBar)[i] = calloc(n, sizeof(int));

    (*G)[i][i] = 1;
    (*GBar)[i][i] = 1;
  }

  int* xi = calloc(n, sizeof(int));
  for(i=0; i<d; i++) {
    for(j=0; j<n; j++){
      xi[j] = (int)randomX[i*n+j];
      //printf("%1.0f ", randomX[i*n+j]);
    }
    //printf("\n");
    //printVector(xi, n);
    shrinkstar(n, k, *h, *G, *GBar, xi, 0);
  }
  free(xi);
  //printf("n-d=%d\n", n-d);
  //printf("k=%d\n", *k);
  //printMatrix(*G, n, n);

  for(i=0; i<n; i++)
    (*h)[i] = rand()%2;

  *Q = (rand()%8); // Q \in Z/8Z
  
  *D = calloc(*k, sizeof(int));
  for(i=0; i<*k; i++)
    (*D)[i] = (rand()%4)*2; // D_a \in {0, 2, 4, 6}

  *J = calloc(*k, sizeof(int*));
  for(i=0; i<*k; i++) {
    (*J)[i] = calloc(*k, sizeof(int));
    for(j=(i+1); j<*k; j++)
      (*J)[i][j] = (rand()%2)*4; // J_{a,b} \in {0, 4} for a!=b
    (*J)[i][i] = (2*(*D)[i])%8;
  }
  for(i=0; i<*k; i++) {
    for(j=(i+1); j<*k; j++) {
      (*J)[j][i] = (*J)[i][j];
    }
  }

  free(randomX); free(randomXcopy); free(randomXsingvals); free(superb); free(U); free(VT);
  return;

}
