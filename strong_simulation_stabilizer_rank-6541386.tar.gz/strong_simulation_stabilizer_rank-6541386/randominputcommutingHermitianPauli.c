#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// order of matrix elements is [row][column]!!!

/*********************************************************/
/* Generates random Hermitian Paulis that are commuting! */
/*********************************************************/
int main( int argc, char *argv[])
{

  if(argc != 3) {
    printf("randominputPauli arguments: \"number of qubits\" \"number of T gates\"\n");
    exit(0);
  }
  
  int N = atoi(argv[1]);              // number of qubits
  int T = atoi(argv[2]);              // number of T gate magic states (set to the first 'K' of the 'N' qubits -- the rest are set to the '0' computational basis state)

  printf("%d\n", N);
  printf("%d\n", T);

  int Pauli[N][N];
  srand((unsigned)time(NULL));


  int i, j, k;

  int sign = 1;
  
  for(i=0; i<N; i++) {
    
    for(j=0; j<N; j++) {
      Pauli[i][j] = rand()%3; // don't generate Y's (which is represented by '3'; I=0, Z=1, X=2, Y=3)
    }
    // see if the new Paulis commute with all the previous ones
    for(j=0; j<i; j++) {
      sign = 1;
      for(k=0; k<N; k++) {
	if(Pauli[j][k] != Pauli[i][k] && Pauli[j][k] != 0 && Pauli[i][k] != 0) // if the Paulis are different and neither is equal to the identity then they anticommute
	  sign *= -1;
      }
      if(sign == -1) {
	i--; // try generating the ith set of Paulis again to get a commuting one
	break; // break out of the loop over j
      }
    }
    if(sign == 1) { // found a commuting set!
      printf("%d\n", (rand()%2)*2); // omega must be 0 or 2 (since it is the power of i: i^omega)
      for(j=0; j<N; j++) {
	printf("%d %d %d %d\n", Pauli[i][j]==0, Pauli[i][j]==1, Pauli[i][j]==2, Pauli[i][j]==3);
      }
    }
  }

}
