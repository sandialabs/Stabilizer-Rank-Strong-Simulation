#!/bin/bash
# Bash script to get some timing analysis:
for j in 10 12 14 16 18
do
for i in {1..1000}
do
./randominputcommutingHermitianPauli $j $j > inputfull.txt && /usr/bin/time -o tmp.txt -a --format=%e ./strongsim < inputfull.txt > /dev/null
sleep 1
done
echo "" >> tmp.txt
done
