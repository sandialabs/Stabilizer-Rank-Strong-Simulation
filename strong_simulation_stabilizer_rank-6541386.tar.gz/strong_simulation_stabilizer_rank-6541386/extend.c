#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>

#include "matrix.h"
#include "extend.h"

// linked list
struct Node {
  int data;
  struct Node* next;
};

void printLinkedList(struct Node *node);
void append(struct Node** head_ref, int new_data);
void freeList(struct Node** head_ref);

/****************************************************************************
 * Attempts to extend the dimension of the affine space by one dimension.
 * The affine space is specified by 
 * the first 'k' columns of the 'n'x'n' matrix 'G', translated by 'h',
 * that will be extended to include the vector 'xi'. 'GBar' is 'G^(-1)^T'.
 ****************************************************************************/

void extend(int n, int *k, int *h, int **G, int **GBar, int *xi) {

  int a;

  struct Node* setS = NULL;
  struct Node* setT = NULL;
  struct Node* setWalker = NULL;

  int i;

  for(a=0; a<*k; a++) {
    if(dotProductMod(xi, GBar[a], n, 2) == 1) {
	append(&setS, a);
    }
  }
  unsigned int firstT = 1; // set initially to true
  for(a=*k; a<n; a++) {
    if(dotProductMod(xi, GBar[a], n, 2) == 1) {
      if(firstT) {
	append(&setT, a);
	i = a;
	firstT = 0;
      }
      else {
	append(&setS, a);
	append(&setT, a);
      }
    }
  }

  if(setT == NULL) {
    freeList(&setS);
    freeList(&setT);
    return; // xi is in the linear space so do nothing
  }

  setWalker = setS;
  while(setWalker != NULL) {
    // update GBar rows, gbar
    for(a=0; a<n; a++)
      GBar[setWalker->data][a] = (GBar[setWalker->data][a] + GBar[i][a])%2;
    // update G rows, g
    for(a=0; a<n; a++)
      G[i][a] = (G[i][a] + G[setWalker->data][a])%2;

    setWalker = setWalker->next;
  }

  // Swap 'i' and 'k+1'
  int* tmpVec;
  tmpVec = G[i];
  G[i] = G[*k];
  G[*k] = tmpVec;
  tmpVec = GBar[i];
  GBar[i] = GBar[*k];
  GBar[*k] = tmpVec;

  freeList(&setS);
  freeList(&setT);
    
  // increment 'k'
  *k = *k + 1;

  return;
    
}


void append(struct Node** head_ref, int new_data) 
{ 
    struct Node* new_node = (struct Node*) malloc(sizeof(struct Node)); 
    struct Node *last = *head_ref;   

    new_node->data = new_data; 
    new_node->next = NULL;

    // if the linked list is empty, then make the new node as head
    if (*head_ref == NULL) {
      *head_ref = new_node; 
      return; 
    }   
       
    // else traverse till the last node
    while (last->next != NULL) {
        last = last->next; 
    }
    last->next = new_node;

    return;     
}

/*void freeList(struct Node** head_ref)
{ 
       
  struct Node *second_last_walker = *head_ref;
  struct Node *walker = *head_ref;   

    // else traverse till the last node
    if(walker != NULL) {
      while(walker->next != NULL) {
	while(walker->next != NULL) {
	  //printf("!%d\n", walker->data);
	  second_last_walker = walker;
	  walker = walker->next;
	  //printf("%d\n", walker->data);
	  //printf("!%d\n", second_last_walker->data);
	}
	free(walker);
	second_last_walker->next = NULL;
	walker = *head_ref;
	//printf("!!%d\n", second_last_walker->data);
      }
    }
    free(walker);
    
    return;     
    }*/

void freeList(struct Node** head_ref)
{ 
       
  struct Node *walker = *head_ref;
  struct Node *walker2;   

    // else traverse till the last node
    if(walker != NULL) {
      walker2 = walker->next;
      while(walker2 != NULL) {
	free(walker);
	walker = walker2;
	walker2 = walker->next;
      }
    }
    free(walker);
    
    return;     
}


void printLinkedList(struct Node *node) 
{
  if(node == NULL)
    printf("NULL\n");
  else {
    while (node != NULL) 
      {
	printf(" %d ", node->data);
	node = node->next; 
      }
  }
  printf("\n");
}
