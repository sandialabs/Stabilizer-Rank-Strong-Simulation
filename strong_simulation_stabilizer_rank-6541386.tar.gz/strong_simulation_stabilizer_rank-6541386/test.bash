#!/bin/bash
# simple Bash script to check if stabilizer rank code works

# choose the number of qubits and T gates on those qubits
# NOTE: numqubits must be a multiple of your gauss sum tensor multiple!
# e.g. if you test gausssums_multipleof6 then numqubits=6*n for some integer n
numqubits=6
numTgates=6

threshold=0.005 # absolute value threshold difference between computed and exact value

numruns=100

echo "Starting test of $numruns random $numqubits-Pauli expectation values..."
for i in $(seq 1 $numruns)
do
# sleep for 1 second for the pseudorandom number generator
sleep 1;a=$(stdbuf -oL ./randominputPauli $numqubits $numTgates > inputfullPauli.txt && ./strongsim < inputfullPauli.txt | tail -1)
b=$(stdbuf -oL ./multipauli < inputfullPauli.txt | tail -n1)
are=$(echo "$a" | cut -f 1 -d " " | cut -c 1-5);
aim=$(echo "$a" | cut -f 3 -d " " | cut -c 1-5); aimsign=$(echo $a | cut -f 2 -d " "); bimsign=$(echo $b | cut -f 2 -d " ");
bre=$(echo "$b" | cut -f 1 -d " " | cut -c 1-5);
bim=$(echo "$b" | cut -f 3 -d " " | cut -c 1-5);
c=$( printf 'scale=5; (%.5f)^2 + (%.5f)^2\n' "$are" "$aim" | bc -l )
echo "$i: $are $aimsign $aim and $bre $bimsign $bim"
rediff=$( printf 'sqrt((%f - %f)^2)\n' "$are" "$bre" | bc -l )
imdiff=$( printf 'sqrt((%f - %f)^2)\n' "$aim" "$bim" | bc -l )
if (( $(echo "$rediff < $threshold" |bc -l) )) && (( $(echo "$imdiff < $threshold" |bc -l) ))
then
    if  (( $(echo "$bim < $threshold" |bc -l) )) || [ "$aimsign" == "$bimsign" ]
    then
	continue
    else
	echo "NOT EQUAL!"
	exit
    fi
  else
    echo "NOT EQUAL!"
    exit
fi
done
echo "Test passed!"
