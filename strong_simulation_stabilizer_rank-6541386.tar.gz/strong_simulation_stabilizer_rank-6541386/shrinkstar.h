char shrinkstar(int n, int *k, int *h, int **G, int **GBar, int *xi, int alpha);
